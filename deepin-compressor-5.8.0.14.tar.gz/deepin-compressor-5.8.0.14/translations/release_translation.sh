lrelease /data/home/hushiwei/workHS/jared777/compressor/translations/*.ts

echo "19891230" | sudo -S cp /data/home/hushiwei/workHS/jared777/compressor/translations/*.qm /usr/share/deepin-compressor/translations
