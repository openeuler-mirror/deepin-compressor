<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Extract</source>
        <translation>Распакуј</translation>
    </message>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Extract here</source>
        <translation>Распакуј овде</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Extract to %b</source>
        <translation>Распакуј у %b</translation>
    </message>
</context>
</TS>