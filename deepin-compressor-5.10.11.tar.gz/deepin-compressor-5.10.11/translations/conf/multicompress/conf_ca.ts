<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Add to &quot;%d.7z&quot;</source>
        <translation>Afegeix a %d.7z</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Add to &quot;%d.zip&quot;</source>
        <translation>Afegeix a %d.zip</translation>
    </message>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Compress</source>
        <translation>Comprimeix</translation>
    </message>
</context>
</TS>