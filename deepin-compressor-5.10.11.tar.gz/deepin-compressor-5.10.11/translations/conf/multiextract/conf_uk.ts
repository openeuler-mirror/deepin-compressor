<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Extract</source>
        <translation>Видобуто</translation>
    </message>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Extract here</source>
        <translation>Видобути до цієї теки</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Extract to %d</source>
        <translation>Видобути до %d</translation>
    </message>
</context>
</TS>