<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Add to &quot;%b.7z&quot;</source>
        <translation>Zu „%b.7z“ hinzufügen</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Add to &quot;%b.zip&quot;</source>
        <translation>Zu „%b.zip“ hinzufügen</translation>
    </message>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Compress</source>
        <translation>Komprimieren</translation>
    </message>
</context>
</TS>