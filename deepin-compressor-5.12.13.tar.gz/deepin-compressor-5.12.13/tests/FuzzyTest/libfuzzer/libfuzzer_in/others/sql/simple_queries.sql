-- SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
--
-- SPDX-License-Identifier: GPL-3.0-or-later

create table t1(one smallint);
insert into t1 values(1);
select * from t1;
