// Copyright (C) 2019 ~ 2020 Uniontech Software Technology Co.,Ltd.
// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

//#include "desktopfileparser_p.h"

//#include "gtest/src/stub.h"

//#include <gtest/gtest.h>

//#include <QTextCodec>
//#include <QJsonObject>
///*******************************函数打桩************************************/


//void ddd();
///*******************************函数打桩************************************/
//TEST(TestDesktopFileParser, testdeserializeList)
//{
////    DesktopFileParser::deserializeList("");
////    DesktopFileParser::deserializeList("\\0");
////    DesktopFileParser::deserializeList("1\\2,");
//}

//TEST(TestDesktopFileParser, testescapeValue)
//{
////    DesktopFileParser::escapeValue("1");

////    DesktopFileParser::escapeValue("\\s\\n\\t\\r\\");
//}

//TEST(TestCustomPropertyDefinition, testfromString)
//{


//}
