<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="438"/>
        <source>Add files to the current archive</source>
        <translation>Añadir archivos al archivo actual</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="443"/>
        <source>Use password</source>
        <translation>Usar contraseña</translation>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>El archivo original de %1 no existe, por favor verifique y vuelve a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 no existe en el disco, por favor verifique y vuelve a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation>No tiene permiso para comprimir %1</translation>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>Actualizando comentario...</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="81"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>Please add files</source>
        <translation>Por favor añada archivos</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="146"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="229"/>
        <source>New Archive</source>
        <translation>Nuevo archivo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="207"/>
        <source>Advanced Options</source>
        <translation>Opciones avanzadas</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Compression method</source>
        <translation>Método de compresión</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="214"/>
        <source>Encrypt the archive</source>
        <translation>Cifrar el archivo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="216"/>
        <source>CPU threads</source>
        <translation>Hilos de CPU</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="218"/>
        <source>Encrypt the file list too</source>
        <translation>Cifrar la lista de archivo también</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="220"/>
        <source>Split to volumes</source>
        <translation>Dividir en volúmenes</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="224"/>
        <source>Compress</source>
        <comment>button</comment>
        <translation>Comprimir</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Store</source>
        <translation>Sin compresión</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fastest</source>
        <translation>Muy rápida</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fast</source>
        <translation>Rápida</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Good</source>
        <translation>Buena</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Best</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>Single thread</source>
        <translation>Un hilo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>2 threads</source>
        <translation>2 hilos</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>4 threads</source>
        <translation>4 hilos</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>8 threads</source>
        <translation>8 hilos</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="260"/>
        <source>Support zip, 7z type only</source>
        <translation>Soporte zip, solo tipo 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="263"/>
        <source>Support 7z type only</source>
        <translation>Soporte solo de tipo 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="275"/>
        <source>Enter up to %1 characters</source>
        <translation>Introduzca hasta %1 caracteres</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="296"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="297"/>
        <source>Save to</source>
        <translation>Guardar en</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="489"/>
        <source>Invalid file name</source>
        <translation>Nombre de archivo inválido</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="495"/>
        <source>Please enter the path</source>
        <translation>Por favor ingrese la ruta</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="500"/>
        <source>The path does not exist, please retry</source>
        <translation>La ruta no existe, por favor vuelva a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="505"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No tiene permisos para guardar archivos aquí, por favor cámbielos e inténtelo de nuevo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="513"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Demasiados volúmenes, por favor cámbielos e inténtelo de nuevo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="522"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="550"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 no existe en el disco, por favor verifique y vuelve a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="557"/>
        <source>You do not have permission to compress %1</source>
        <translation>No tiene permisos para comprimir %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="548"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>El archivo original de %1 no existe, por favor verifique y vuelve a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="583"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="705"/>
        <source>Total size: %1</source>
        <translation>Tamaño total: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="725"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>El nombre es el mismo que el del archivo comprimido, por favor utilice otro</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="733"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation>La contraseña de los volúmenes ZIP no puede estar en chino</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ya existe otro archivo con el mismo nombre, ¿desea remplazarlo?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="837"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation>Solo símbolos y caracteres en inglés y chino están admitidos</translation>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="296"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="314"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="317"/>
        <source>Open with</source>
        <translation>Abrir con</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="321"/>
        <location filename="../src/source/tree/compressview.cpp" line="500"/>
        <source>Select default program</source>
        <translation>Seleccionar programa predeterminado</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>Eliminará permanentemente los archivos. ¿Está seguro que quiere continuar?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <location filename="../src/source/tree/compressview.cpp" line="474"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="475"/>
        <source>Add</source>
        <comment>button</comment>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="473"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>¿Desea añadir el archivo a la lista o abrirlo en una nueva ventana?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="476"/>
        <source>Open in new window</source>
        <translation>Abrir en una nueva ventana</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="312"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>No se admiten cambios en este tipo de archivos. Por favor convierta el archivo a otro formato para guardar los cambios.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Convert the format to:</source>
        <translation>Convertir el formato a:</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="344"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="345"/>
        <source>Convert</source>
        <comment>button</comment>
        <translation>Convertir</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>elemento(s)</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="87"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>La extracción falló</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="100"/>
        <source>Damaged file, unable to extract</source>
        <translation>Archivo dañado, no se puede extraer</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="105"/>
        <source>Retry</source>
        <comment>button</comment>
        <translation>Reintentar</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="108"/>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Arrastre archivo o carpeta aquí</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Seleccionar archivo</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>The archive is damaged</source>
        <translation>El archivo está dañado</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="528"/>
        <source>Open as read-only</source>
        <translation>Abierto solo para lectura</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="529"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Cargando, por favor espere...</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <location filename="../src/main.cpp" line="61"/>
        <source>Archive Manager</source>
        <translation>Compresor de archivos</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="62"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>Compresor de archivos de Deepin es una ligera y rápida aplicación para comprimir y extraer archivos.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="179"/>
        <source>Open file</source>
        <translation>Abrir archivo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="180"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="276"/>
        <location filename="../src/source/mainwindow.cpp" line="286"/>
        <source>Create New Archive</source>
        <translation>Crear nuevo fichero</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="334"/>
        <source>Converting</source>
        <translation>Convirtiendo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="341"/>
        <source>Updating comments</source>
        <translation>Actualizando comentarios</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="2071"/>
        <location filename="../src/source/mainwindow.cpp" line="2097"/>
        <location filename="../src/source/mainwindow.cpp" line="2122"/>
        <source>Plugin error</source>
        <translation>Error de plugin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1284"/>
        <source>Adding successful</source>
        <translation>Agregado exitosamente</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2146"/>
        <source>No data in it</source>
        <translation>No hay datos en él</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1521"/>
        <source>Adding canceled</source>
        <translation>Agregado abortado</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1623"/>
        <source>Adding failed</source>
        <translation>Error al añadir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1676"/>
        <source>Extraction failed: the file name is too long</source>
        <translation>La extracción falló: el nombre del archivo es demasiado largo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1703"/>
        <location filename="../src/source/mainwindow.cpp" line="2142"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation>Error al crear &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1825"/>
        <source>Open failed: the file name is too long</source>
        <translation>Error al abrir: el nombre del archivo es demasiado largo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2044"/>
        <source>Compression successful</source>
        <translation>Compresión exitosa</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2050"/>
        <source>The file name is too long, so the first 60 characters have been intercepted as the file name.</source>
        <translation>El nombre del archivo es demasiado largo, por lo que los primeros 60 caracteres se utilizaron como nombre del archivo.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2079"/>
        <location filename="../src/source/mainwindow.cpp" line="2150"/>
        <source>Insufficient disk space</source>
        <translation>Espacio de disco insuficiente</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <location filename="../src/source/mainwindow.cpp" line="2130"/>
        <source>Some volumes are missing</source>
        <translation>Algunos volúmenes están desaperecidos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2134"/>
        <source>Wrong password, please retry</source>
        <translation>Contraseña incorrecta, por favor reintente</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2138"/>
        <location filename="../src/source/mainwindow.cpp" line="2162"/>
        <source>The file name is too long. Keep the name within 60 characters please.</source>
        <translation>El nombre del archivo es demasiado largo. Mantenga el nombre dentro de los 60 caracteres, por favor.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2159"/>
        <source>Conversion failed</source>
        <translation>La conversión falló</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2297"/>
        <source>Select file</source>
        <translation>Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3167"/>
        <source>Enter up to %1 characters</source>
        <translation>Introduzca hasta %1 caracteres</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3043"/>
        <source>File info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Do you want to delete the archive?</source>
        <translation>¿Desea borrar el archivo?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="533"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1 fué cambiado en el disco, por favor vuelva a importarlo.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="75"/>
        <source>Archive Manager</source>
        <translation>Compresor de archivos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No tiene permisos para guardar archivos aquí, por favor cámbielos e inténtelo de nuevo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="299"/>
        <source>Adding files to %1</source>
        <translation>Añadiendo archivos a %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Compressing</source>
        <translation>Comprimiendo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="313"/>
        <source>Extracting</source>
        <translation>Extrayendo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="320"/>
        <source>Deleting</source>
        <translation>Borrando</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="493"/>
        <location filename="../src/source/mainwindow.cpp" line="2867"/>
        <source>Loading, please wait...</source>
        <translation>Cargando, por favor espere...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>¿Está seguro que quiere detener la tarea en curso?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1290"/>
        <location filename="../src/source/mainwindow.cpp" line="1417"/>
        <location filename="../src/source/mainwindow.cpp" line="1433"/>
        <source>Updating, please wait...</source>
        <translation>Actualizando, por favor espere...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1698"/>
        <source>File name too long</source>
        <translation>El nombre del archivo es muy largo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2075"/>
        <source>Failed to create file</source>
        <translation>Error al crear archivo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2068"/>
        <source>Compression failed</source>
        <translation>La compresión falló</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2471"/>
        <source>Find directory</source>
        <translation>Buscar carpeta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2094"/>
        <source>Open failed</source>
        <translation>Error al abrir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1619"/>
        <location filename="../src/source/mainwindow.cpp" line="1693"/>
        <location filename="../src/source/mainwindow.cpp" line="1768"/>
        <location filename="../src/source/mainwindow.cpp" line="1823"/>
        <location filename="../src/source/mainwindow.cpp" line="2105"/>
        <source>Wrong password</source>
        <translation>Contraseña incorrecta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="645"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation>El formato de archivo no es compatible con el compresor de archivos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="536"/>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="652"/>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <location filename="../src/source/mainwindow.cpp" line="2729"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="327"/>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <source>You do not have permission to load %1</source>
        <translation>No tiene permiso para cargar %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <source>No such file or directory</source>
        <translation>No hay tal archivo o directorio</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1332"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Extracción exitosa</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1542"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation>Extracción cancelada</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1688"/>
        <location filename="../src/source/mainwindow.cpp" line="1763"/>
        <location filename="../src/source/mainwindow.cpp" line="2101"/>
        <location filename="../src/source/mainwindow.cpp" line="2126"/>
        <source>The archive is damaged</source>
        <translation>El archivo está dañado</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2048"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Extracción exitosa</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2054"/>
        <source>Conversion successful</source>
        <translation>Conversión exitosa</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2083"/>
        <source>The compressed volumes already exist</source>
        <translation>Los volúmenes comprimidos ya existen</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2119"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>La extracción falló</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2289"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2293"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2301"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2309"/>
        <source>Display shortcuts</source>
        <translation>Mostrar atajos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2321"/>
        <source>Shortcuts</source>
        <translation>Atajos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2399"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>El nombre es el mismo que el del archivo comprimido, por favor utilice otro</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ya existe otro archivo con el mismo nombre, ¿desea remplazarlo?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2550"/>
        <source>You cannot add the archive to itself</source>
        <translation>No se puede añadir el archivo a sí mismo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <source>You cannot add files to archives in this file type</source>
        <translation>No se pueden añadir archivos para este tipo de compresión</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Update</source>
        <comment>button</comment>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3067"/>
        <source>Basic info</source>
        <translation>Información básica</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3083"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3084"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3085"/>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Time created</source>
        <translation>Fecha de creación</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3087"/>
        <source>Time accessed</source>
        <translation>Fecha de acceso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3088"/>
        <source>Time modified</source>
        <translation>Fecha de modificación</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3098"/>
        <source>Archive</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3129"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="642"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Verifique la asociación del tipo de archivo en la configuración del Administrador de archivos</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>El fichero fué cambiado en el disco, por favor vuelva a intentarlo.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>Ejecutable</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>Archivo de respaldo</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Abrir con</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Add other programs</source>
        <translation>Añadir otros programas</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="301"/>
        <source>Set as default</source>
        <translation>Establecer como predeterminado</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="304"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="308"/>
        <source>Recommended Applications</source>
        <translation>Aplicaciones recomendadas</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="310"/>
        <source>Other Applications</source>
        <translation>Otras aplicaciones</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>Archivo cifrado, por favor ingrese la contraseña</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation>Ruta actual:</translation>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation>Volver a: %1</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>%1 tarea(s) en progreso</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Tarea</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>Extrayendo</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>¿Está seguro que desea detener la extracción?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="325"/>
        <location filename="../src/source/page/progresspage.cpp" line="328"/>
        <location filename="../src/source/page/progresspage.cpp" line="331"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="160"/>
        <source>Calculating...</source>
        <translation>Calculando…</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="335"/>
        <location filename="../src/source/page/progresspage.cpp" line="337"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="341"/>
        <location filename="../src/source/page/progresspage.cpp" line="343"/>
        <source>Speed</source>
        <comment>rename</comment>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="355"/>
        <location filename="../src/source/page/progresspage.cpp" line="357"/>
        <location filename="../src/source/page/progresspage.cpp" line="359"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="347"/>
        <location filename="../src/source/page/progresspage.cpp" line="349"/>
        <location filename="../src/source/page/progresspage.cpp" line="351"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="321"/>
        <source>Time left</source>
        <translation>Tiempo restante</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="131"/>
        <source>Compressing</source>
        <translation>Comprimiendo</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="133"/>
        <source>Deleting</source>
        <translation>Borrando</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="135"/>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="137"/>
        <source>Converting</source>
        <translation>Convirtiendo</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="139"/>
        <location filename="../src/source/page/progresspage.cpp" line="158"/>
        <source>Updating the comment...</source>
        <translation>Actualizando comentario...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="141"/>
        <source>Extracting</source>
        <translation>Extrayendo</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="152"/>
        <location filename="../src/source/page/progresspage.cpp" line="189"/>
        <location filename="../src/source/page/progresspage.cpp" line="375"/>
        <source>Pause</source>
        <comment>button</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="188"/>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="371"/>
        <source>Continue</source>
        <comment>button</comment>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="393"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation>¿Está seguro que desea detener la descompresión?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="395"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation>¿Está seguro de que desea detener el borrado eliminación?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="391"/>
        <location filename="../src/source/page/progresspage.cpp" line="397"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>¿Está seguro que desea detener la compresión?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="399"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>¿Está seguro que quiere detener la conversión?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Fecha de modificación</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2886"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>%1 cambió. ¿Desea guardar los cambios en el archivo?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Extracción</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Crear automáticamente una carpeta para múltiples archivos extraidos</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Mostrar archivos extraídos al terminar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Administración de archivos</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Borrar archivos después de comprimir</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>Archivos asociados</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Tipo de archivo</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="214"/>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <source>Skip</source>
        <comment>button</comment>
        <translation>Omitir</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Merge</source>
        <comment>button</comment>
        <translation>Fusionar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ya existe otro archivo con el mismo nombre, ¿desea remplazarlo?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="215"/>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="483"/>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="484"/>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation>Ya existe otra carpeta con el mismo nombre, ¿desea reemplazarla?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="218"/>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <source>Apply to all</source>
        <translation>Aplicar a todos</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="557"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="608"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="609"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="619"/>
        <source>The name already exists</source>
        <translation>El nombre ya existe</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Carpeta actual</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Limpiar todos</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <comment>button</comment>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Recomendado</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Extraer ficheros en</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Otra carpeta</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Borrar archivos después de extraer</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Pedir confirmación</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>Compression successful</source>
        <translation>Compresión exitosa</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="89"/>
        <source>View</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="92"/>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3324"/>
        <location filename="../src/source/mainwindow.cpp" line="3381"/>
        <source>Open file</source>
        <translation>Abrir archivo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3327"/>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3386"/>
        <source>File info</source>
        <translation>Información</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="75"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="87"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="116"/>
        <source>Extract to:</source>
        <translation>Extraer en:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="117"/>
        <source>Extract</source>
        <comment>button</comment>
        <translation>Extraer</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="193"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>La ruta de extracción por defecto no existe, por favor vuelva a intentarlo</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="195"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No tiene permisos para guardar archivos aquí, por favor cámbielos e inténtelo de nuevo</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="199"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="213"/>
        <source>Find directory</source>
        <translation>Buscar carpeta</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>You cannot add the archive to itself</source>
        <translation>No se puede añadir un archivo a sí mismo</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="627"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Extraer</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Extract to current directory</source>
        <translation>Extraer en la carpeta actual</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="631"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="638"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="645"/>
        <source>Open with</source>
        <translation>Abrir con</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="649"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="790"/>
        <source>Select default program</source>
        <translation>Seleccionar programa predeterminado</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>¿Desea borrar los archivos seleccionados?</translation>
    </message>
</context>
</TS>