<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ca">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="438"/>
        <source>Add files to the current archive</source>
        <translation>Afegeix fitxers a l&apos;arxiu actual</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="443"/>
        <source>Use password</source>
        <translation>Usa la contrasenya</translation>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>El fitxer original de %1 no existeix. Si us plau, comproveu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 no existeix al disc. Si us plau, comproveu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation>No teniu permís per comprimir %1</translation>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>S&apos;actualitza el comentari...</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="81"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>Please add files</source>
        <translation>Si us plau, afegiu-hi fitxers.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="146"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="229"/>
        <source>New Archive</source>
        <translation>Arxiu nou</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="207"/>
        <source>Advanced Options</source>
        <translation>Opcions avançades</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Compression method</source>
        <translation>Mètode de compressió</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="214"/>
        <source>Encrypt the archive</source>
        <translation>Xifra el fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="216"/>
        <source>CPU threads</source>
        <translation>Fils de la CPU</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="218"/>
        <source>Encrypt the file list too</source>
        <translation>Xifra també la llista de fitxers</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="220"/>
        <source>Split to volumes</source>
        <translation>Divideix en volums</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>Comment</source>
        <translation>Comentari</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="224"/>
        <source>Compress</source>
        <comment>button</comment>
        <translation>Comprimeix</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Store</source>
        <translation>Emmagatzematge</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fastest</source>
        <translation>Rapidíssim</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fast</source>
        <translation>Ràpid</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Good</source>
        <translation>Bo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Best</source>
        <translation>Millor</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>Single thread</source>
        <translation>Fil únic</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>2 threads</source>
        <translation>2 fils</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>4 threads</source>
        <translation>4 fils</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>8 threads</source>
        <translation>8 fils</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="260"/>
        <source>Support zip, 7z type only</source>
        <translation>Només compatible amb zip i 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="263"/>
        <source>Support 7z type only</source>
        <translation>Només compatible amb 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="275"/>
        <source>Enter up to %1 characters</source>
        <translation>Escriviu fins a %1 caràcters.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="296"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="297"/>
        <source>Save to</source>
        <translation>Desa a</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="489"/>
        <source>Invalid file name</source>
        <translation>Nom de fitxer no vàlid</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="495"/>
        <source>Please enter the path</source>
        <translation>Si us plau, introduïu el camí.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="500"/>
        <source>The path does not exist, please retry</source>
        <translation>El camí no existeix. Torneu-ho a provar!</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="505"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No teniu permís per desar fitxers aquí. Si us plau, canvieu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="513"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Massa volums. Si us plau, canvieu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="522"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="550"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 no existeix al disc. Si us plau, comproveu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="557"/>
        <source>You do not have permission to compress %1</source>
        <translation>No teniu permís per comprimir %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="548"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>El fitxer original de %1 no existeix. Si us plau, comproveu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="583"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="705"/>
        <source>Total size: %1</source>
        <translation>Mida total: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="725"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>El nom és igual al de l&apos;arxiu comprimit. Si us plau, useu-ne un altre.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="733"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation>La contrasenya per als volums ZIP no pot ser en xinès.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ja existeix un altre fitxer amb el mateix nom. Voleu reemplaçar-lo?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="837"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation>Només s&apos;admeten caràcters xinesos i anglesos i alguns símbols.</translation>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="296"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <source>Rename</source>
        <translation>Canvia&apos;n el nom</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="314"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="317"/>
        <source>Open with</source>
        <translation>Obre amb</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="321"/>
        <location filename="../src/source/tree/compressview.cpp" line="500"/>
        <source>Select default program</source>
        <translation>Trieu el programa per defecte</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>S&apos;eliminaran permanentment els fitxers. Segur que voleu continuar?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <location filename="../src/source/tree/compressview.cpp" line="474"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="475"/>
        <source>Add</source>
        <comment>button</comment>
        <translation>Afegeix</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="473"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>Voleu afegir el fitxer a la llista o obrir-lo en una finestra nova?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="476"/>
        <source>Open in new window</source>
        <translation>Obre en una finestra nova</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="312"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>Els canvis dels arxius d&apos;aquest tipus de fitxers no són compatibles. Convertiu el format d’arxiu per desar els canvis.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Convert the format to:</source>
        <translation>Converteix-ne el format a:</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="344"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="345"/>
        <source>Convert</source>
        <comment>button</comment>
        <translation>Converteix</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>element/s</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="87"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>L&apos;extracció ha fallat.</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="100"/>
        <source>Damaged file, unable to extract</source>
        <translation>Fitxer malmès, no es pot extreure.</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="105"/>
        <source>Retry</source>
        <comment>button</comment>
        <translation>Torna-ho a provar</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="108"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Arrossegueu un fitxer o una carpeta aquí.</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Trieu un fitxer</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>The archive is damaged</source>
        <translation>L&apos;arxiu està danyat.</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="528"/>
        <source>Open as read-only</source>
        <translation>L&apos;obertura és només de lectura.</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="529"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Es carrega. Espereu, si us plau...</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <location filename="../src/main.cpp" line="61"/>
        <source>Archive Manager</source>
        <translation>Gestor d&apos;arxius</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="62"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>El Gestor d&apos;arxius és una aplicació lleugera i ràpida per crear i descomprimir arxius.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="179"/>
        <source>Open file</source>
        <translation>Obre el fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="180"/>
        <source>Settings</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="276"/>
        <location filename="../src/source/mainwindow.cpp" line="286"/>
        <source>Create New Archive</source>
        <translation>Crea un nou fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="334"/>
        <source>Converting</source>
        <translation>Es converteix</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="341"/>
        <source>Updating comments</source>
        <translation>S&apos;actualitzen els comentaris.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="2071"/>
        <location filename="../src/source/mainwindow.cpp" line="2097"/>
        <location filename="../src/source/mainwindow.cpp" line="2122"/>
        <source>Plugin error</source>
        <translation>Error del connector</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1284"/>
        <source>Adding successful</source>
        <translation>Addició correcta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2146"/>
        <source>No data in it</source>
        <translation>No hi ha dades.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1521"/>
        <source>Adding canceled</source>
        <translation>S&apos;ha cancel·lat l&apos;addició.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1623"/>
        <source>Adding failed</source>
        <translation>Ha fallat l&apos;addició.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1676"/>
        <source>Extraction failed: the file name is too long</source>
        <translation>Ha fallat l&apos;extracció: el nom del fitxer és massa llarg.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1703"/>
        <location filename="../src/source/mainwindow.cpp" line="2142"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation>Ha fallat crear &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1825"/>
        <source>Open failed: the file name is too long</source>
        <translation>Ha fallat obrir-lo: el nom del fitxer és massa llarg.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2044"/>
        <source>Compression successful</source>
        <translation>Compressió correcta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2050"/>
        <source>The file name is too long, so the first 60 characters have been intercepted as the file name.</source>
        <translation>El nom del fitxer és massa llarg, de manera que els primers 60 caràcters s&apos;han pres com a nom del fitxer.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2079"/>
        <location filename="../src/source/mainwindow.cpp" line="2150"/>
        <source>Insufficient disk space</source>
        <translation>Espai de disc insuficient</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <location filename="../src/source/mainwindow.cpp" line="2130"/>
        <source>Some volumes are missing</source>
        <translation>Manquen alguns volums</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2134"/>
        <source>Wrong password, please retry</source>
        <translation>Contrasenya incorrecta. Torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2138"/>
        <location filename="../src/source/mainwindow.cpp" line="2162"/>
        <source>The file name is too long. Keep the name within 60 characters please.</source>
        <translation>El nom del fitxer és massa llarg. Si us plau, manteniu el nom amb un màxim de 60 caràcters.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2159"/>
        <source>Conversion failed</source>
        <translation>Ha fallat la conversió.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2297"/>
        <source>Select file</source>
        <translation>Seleccioneu un fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3167"/>
        <source>Enter up to %1 characters</source>
        <translation>Escriviu fins a %1 caràcters.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3043"/>
        <source>File info</source>
        <translation>Informació del fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Do you want to delete the archive?</source>
        <translation>Voleu eliminar l&apos;arxiu?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="533"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1 ha canviat al disc. Si us plau, torneu-lo a importar.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="75"/>
        <source>Archive Manager</source>
        <translation>Gestor d&apos;arxius</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No teniu permís per desar fitxers aquí. Si us plau, canvieu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="299"/>
        <source>Adding files to %1</source>
        <translation>S&apos;afegeixen fitxers a %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Compressing</source>
        <translation>Es comprimeix</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="313"/>
        <source>Extracting</source>
        <translation>S&apos;extreu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="320"/>
        <source>Deleting</source>
        <translation>S&apos;elimina</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="493"/>
        <location filename="../src/source/mainwindow.cpp" line="2867"/>
        <source>Loading, please wait...</source>
        <translation>Es carrega. Espereu, si us plau...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>Segur que voleu interrompre la tasca activa?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1290"/>
        <location filename="../src/source/mainwindow.cpp" line="1417"/>
        <location filename="../src/source/mainwindow.cpp" line="1433"/>
        <source>Updating, please wait...</source>
        <translation>S&apos;actualitza. Espereu, si us plau...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1698"/>
        <source>File name too long</source>
        <translation>Nom del fitxer massa llarg.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2075"/>
        <source>Failed to create file</source>
        <translation>Ha fallat crear el fitxer.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2068"/>
        <source>Compression failed</source>
        <translation>La compressió ha fallat.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2471"/>
        <source>Find directory</source>
        <translation>Troba un directori</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2094"/>
        <source>Open failed</source>
        <translation>Ha fallat l&apos;obertura.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1619"/>
        <location filename="../src/source/mainwindow.cpp" line="1693"/>
        <location filename="../src/source/mainwindow.cpp" line="1768"/>
        <location filename="../src/source/mainwindow.cpp" line="1823"/>
        <location filename="../src/source/mainwindow.cpp" line="2105"/>
        <source>Wrong password</source>
        <translation>Contrasenya incorrecta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="645"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation>El format del fitxer no l&apos;admet el Gestor d&apos;arxius.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="536"/>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="652"/>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <location filename="../src/source/mainwindow.cpp" line="2729"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="327"/>
        <source>Renaming</source>
        <translation>Canvi de nom</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <source>You do not have permission to load %1</source>
        <translation>No teniu permís per carregar %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <source>No such file or directory</source>
        <translation>No hi ha tal fitxer o directori.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1332"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Extracció correcta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1542"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation>S&apos;ha cancel·lat l&apos;extracció.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1688"/>
        <location filename="../src/source/mainwindow.cpp" line="1763"/>
        <location filename="../src/source/mainwindow.cpp" line="2101"/>
        <location filename="../src/source/mainwindow.cpp" line="2126"/>
        <source>The archive is damaged</source>
        <translation>L&apos;arxiu està danyat.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2048"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Extracció correcta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2054"/>
        <source>Conversion successful</source>
        <translation>Conversió correcta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2083"/>
        <source>The compressed volumes already exist</source>
        <translation>Els volums comprimits ja existeixen.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2119"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>L&apos;extracció ha fallat.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2289"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2293"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2301"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2309"/>
        <source>Display shortcuts</source>
        <translation>Mostra les dreceres</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2321"/>
        <source>Shortcuts</source>
        <translation>Dreceres</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2399"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>El nom és igual al de l&apos;arxiu comprimit. Si us plau, useu-ne un altre.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ja existeix un altre fitxer amb el mateix nom. Voleu reemplaçar-lo?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2550"/>
        <source>You cannot add the archive to itself</source>
        <translation>No podeu afegir un arxiu a si mateix.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <source>You cannot add files to archives in this file type</source>
        <translation>No podeu afegir fitxers d&apos;aquest tipus a arxius.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Update</source>
        <comment>button</comment>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3067"/>
        <source>Basic info</source>
        <translation>Informació bàsica</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3083"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3084"/>
        <source>Type</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3085"/>
        <source>Location</source>
        <translation>Ubicació</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Time created</source>
        <translation>Hora de creació</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3087"/>
        <source>Time accessed</source>
        <translation>Hora d&apos;accés</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3088"/>
        <source>Time modified</source>
        <translation>Modificat</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3098"/>
        <source>Archive</source>
        <translation>Arxiva</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3129"/>
        <source>Comment</source>
        <translation>Comentari</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="642"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Si us plau, comproveu el tipus d&apos;associació de fitxers a la configuració del Gestor d&apos;arxius.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>L&apos;arxiu ha canviat al disc. Si us plau, torneu-lo a importar.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Directori</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Aplicació</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Àudio</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Imatge</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Arxiva</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>Executable</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>Fitxer de còpia de seguretat</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Obre amb</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Add other programs</source>
        <translation>Afegeix altres programes</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="301"/>
        <source>Set as default</source>
        <translation>Estableix-lo per defecte</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="304"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="308"/>
        <source>Recommended Applications</source>
        <translation>Aplicacions recomanades</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="310"/>
        <source>Other Applications</source>
        <translation>Altres aplicacions</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>Fitxer encriptat. Si us plau, introduïu-ne la contrasenya.</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation>Camí actual:</translation>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation>Enrere a: %1</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>%1 tasca/ques en curs</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Tasca</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>S&apos;extreu</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>Segur que voleu interrompre&apos;n l&apos;extracció?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="325"/>
        <location filename="../src/source/page/progresspage.cpp" line="328"/>
        <location filename="../src/source/page/progresspage.cpp" line="331"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="160"/>
        <source>Calculating...</source>
        <translation>Es calcula...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="335"/>
        <location filename="../src/source/page/progresspage.cpp" line="337"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="341"/>
        <location filename="../src/source/page/progresspage.cpp" line="343"/>
        <source>Speed</source>
        <comment>rename</comment>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="355"/>
        <location filename="../src/source/page/progresspage.cpp" line="357"/>
        <location filename="../src/source/page/progresspage.cpp" line="359"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="347"/>
        <location filename="../src/source/page/progresspage.cpp" line="349"/>
        <location filename="../src/source/page/progresspage.cpp" line="351"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="321"/>
        <source>Time left</source>
        <translation>Temps restant</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="131"/>
        <source>Compressing</source>
        <translation>Es comprimeix</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="133"/>
        <source>Deleting</source>
        <translation>S&apos;elimina</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="135"/>
        <source>Renaming</source>
        <translation>Canvi de nom</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="137"/>
        <source>Converting</source>
        <translation>Es converteix</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="139"/>
        <location filename="../src/source/page/progresspage.cpp" line="158"/>
        <source>Updating the comment...</source>
        <translation>S&apos;actualitza el comentari...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="141"/>
        <source>Extracting</source>
        <translation>S&apos;extreu</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="152"/>
        <location filename="../src/source/page/progresspage.cpp" line="189"/>
        <location filename="../src/source/page/progresspage.cpp" line="375"/>
        <source>Pause</source>
        <comment>button</comment>
        <translation>Interromp</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="188"/>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="371"/>
        <source>Continue</source>
        <comment>button</comment>
        <translation>Continua</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="393"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation>Segur que voleu interrompre&apos;n la descompressió?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="395"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation>Segur que voleu interrompre&apos;n la supressió?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="391"/>
        <location filename="../src/source/page/progresspage.cpp" line="397"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>Segur que voleu interrompre&apos;n la compressió?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="399"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>Segur que voleu interrompre&apos;n la conversió?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Modificat</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2886"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>%1 ha canviat. Voleu desar els canvis a l&apos;arxiu?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Extracció</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Crea una carpeta automàticament per a l&apos;extracció de múltiples fitxers.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Mostra els fitxers extrets en acabar.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Gestió de fitxers</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Elimina els fitxers després de la compressió.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>Fitxers associats</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Tipus de fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="214"/>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <source>Skip</source>
        <comment>button</comment>
        <translation>Omet</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Merge</source>
        <comment>button</comment>
        <translation>Fusiona</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Ja existeix un altre fitxer amb el mateix nom. Voleu reemplaçar-lo?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="215"/>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="483"/>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="484"/>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation>Ja existeix una altra carpeta amb el mateix nom. Voleu reemplaçar-la?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="218"/>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <source>Apply to all</source>
        <translation>Aplica-ho a tot</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="557"/>
        <source>Rename</source>
        <translation>Canvia&apos;n el nom</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="608"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="609"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="619"/>
        <source>The name already exists</source>
        <translation>El nom ja existeix.</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Directori actual</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Neteja-ho tot</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <comment>button</comment>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Recomanat</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Extreu els arxius a</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Altre directori</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Elimina els arxius després de l&apos;extracció.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Demana&apos;n la confirmació.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>Compression successful</source>
        <translation>Compressió correcta</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="89"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="92"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3324"/>
        <location filename="../src/source/mainwindow.cpp" line="3381"/>
        <source>Open file</source>
        <translation>Obre el fitxer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3327"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3386"/>
        <source>File info</source>
        <translation>Informació del fitxer</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="75"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="87"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="116"/>
        <source>Extract to:</source>
        <translation>Extreu a:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="117"/>
        <source>Extract</source>
        <comment>button</comment>
        <translation>Extreu</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="193"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>El camí d&apos;extracció per defecte no existeix. Torneu-ho a provar, si us plau.</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="195"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>No teniu permís per desar fitxers aquí. Si us plau, canvieu-ho i torneu-ho a provar.</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="199"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="213"/>
        <source>Find directory</source>
        <translation>Troba un directori</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>You cannot add the archive to itself</source>
        <translation>No podeu afegir un arxiu a si mateix.</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="627"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Extreu</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Extract to current directory</source>
        <translation>Extreu-ho al directori actual</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="631"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <source>Rename</source>
        <translation>Canvia&apos;n el nom</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="638"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="645"/>
        <source>Open with</source>
        <translation>Obre amb</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="649"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="790"/>
        <source>Select default program</source>
        <translation>Trieu el programa per defecte</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Confirmeu-ho</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>Voleu eliminar el/s fitxer/s seleccionat/s?</translation>
    </message>
</context>
</TS>