<?xml version="1.0" ?><!DOCTYPE TS><TS language="bo" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Extract</source>
        <translation>བསྡུས་འགྲོལ།</translation>
    </message>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Extract here</source>
        <translation>མིག་སྔའི་ཡིག་ཁུག་ཏུ་བསྡུས་འགྲོལ་ལམ་གནོན་བཙིར་བྱ་རྒྱུ། </translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Extract to %d</source>
        <translation>%dབར་བསྡུས་འགྲོལ་བྱེད་པ།</translation>
    </message>
</context>
</TS>