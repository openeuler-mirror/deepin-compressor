<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Extract</source>
        <translation>Wypakuj</translation>
    </message>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Extract here</source>
        <translation>Wypakuj tutaj</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Extract to %b</source>
        <translation>Wypakuj do %b</translation>
    </message>
</context>
</TS>