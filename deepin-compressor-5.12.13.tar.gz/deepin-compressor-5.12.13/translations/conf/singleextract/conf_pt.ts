<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Extract</source>
        <translation>Extrair</translation>
    </message>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Extract here</source>
        <translation>Extrair aqui</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Extract to %b</source>
        <translation>Extrair para %b</translation>
    </message>
</context>
</TS>