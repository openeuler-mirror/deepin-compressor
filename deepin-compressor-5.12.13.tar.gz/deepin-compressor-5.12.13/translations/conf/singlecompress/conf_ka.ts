<?xml version="1.0" ?><!DOCTYPE TS><TS language="ka" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Add to &quot;%b.7z&quot;</source>
        <translation>&quot;%d.7z&quot;-ში დამატება</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Add to &quot;%b.zip&quot;</source>
        <translation>&quot;%d.zip&quot;-ში დამატება</translation>
    </message>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Compress</source>
        <translation>შეკუმშვა</translation>
    </message>
</context>
</TS>