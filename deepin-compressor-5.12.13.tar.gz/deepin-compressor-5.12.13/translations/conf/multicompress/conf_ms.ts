<?xml version="1.0" ?><!DOCTYPE TS><TS language="ms" version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="Menu Action One]Name" line="0"/>
        <source>Add to &quot;%d.7z&quot;</source>
        <translation>Tambah ke &quot;%d.7z&quot;</translation>
    </message>
    <message>
        <location filename="Menu Action Two]Name" line="0"/>
        <source>Add to &quot;%d.zip&quot;</source>
        <translation>Tambah ke &quot;%d.zip&quot;</translation>
    </message>
    <message>
        <location filename="Menu Action Zero]Name" line="0"/>
        <source>Compress</source>
        <translation>Mampat</translation>
    </message>
</context>
</TS>