<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="438"/>
        <source>Add files to the current archive</source>
        <translation>Aggiungi file all&apos;archivio attuale</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="443"/>
        <source>Use password</source>
        <translation>Utilizza una password</translation>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>Il file originale di %1 non esiste, verifica e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 non esiste sul disco, verifica e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation>Non hai l&apos;autorizzazione per comprimere %1</translation>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>Aggiornamento commenti...</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="81"/>
        <source>Next</source>
        <translation>Prossimo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>Please add files</source>
        <translation>Aggiungi file</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="122"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="146"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="229"/>
        <source>New Archive</source>
        <translation>Nuovo Archivio</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="207"/>
        <source>Advanced Options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Compression method</source>
        <translation>Metodo di compressione</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="214"/>
        <source>Encrypt the archive</source>
        <translation>Crittografa l&apos;archivio</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="216"/>
        <source>CPU threads</source>
        <translation>Thread CPU</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="218"/>
        <source>Encrypt the file list too</source>
        <translation>Crittografa anche la lista dei file</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="220"/>
        <source>Split to volumes</source>
        <translation>Suddividi in volumi</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>Comment</source>
        <translation>Commenti</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="224"/>
        <source>Compress</source>
        <comment>button</comment>
        <translation>Comprimi</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Store</source>
        <translation>Archivia</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fastest</source>
        <translation>Più veloce</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Fast</source>
        <translation>Veloce</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Good</source>
        <translation>Buona</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="243"/>
        <source>Best</source>
        <translation>Migliore</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>Single thread</source>
        <translation>Thread singolo</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>2 threads</source>
        <translation>2 thread</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>4 threads</source>
        <translation>4 thread</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="250"/>
        <source>8 threads</source>
        <translation>8 thread</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="260"/>
        <source>Support zip, 7z type only</source>
        <translation>Supporta zip, solo in formato 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="263"/>
        <source>Support 7z type only</source>
        <translation>Supporta solo il formato 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="275"/>
        <source>Enter up to %1 characters</source>
        <translation>Inserisci più di %1 caratteri</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="296"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="297"/>
        <source>Save to</source>
        <translation>Salva in</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="489"/>
        <source>Invalid file name</source>
        <translation>Nome file non valido</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="495"/>
        <source>Please enter the path</source>
        <translation>Inserisci il percorso</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="500"/>
        <source>The path does not exist, please retry</source>
        <translation>Il percorso non esiste, riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="505"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Non hai l&apos;autorizzazione per salvare il file qui, scegli un altro percorso e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="513"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Troppi volumi, riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="522"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="550"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 non esiste sul disco, verifica e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="557"/>
        <source>You do not have permission to compress %1</source>
        <translation>Non hai l&apos;autorizzazione per comprimere %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="548"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>Il file originale di %1 non esiste, verifica e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="583"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Sostituisci</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="705"/>
        <source>Total size: %1</source>
        <translation>Dimensione totale: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="725"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>Il nome è il medesimo dell&apos;archivio compresso, per cortesia utilizza un nome differente</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="733"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation>La password per gli archivi ZIP non può essere in Cinese</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="797"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Esiste già un file con lo stesso nome, desideri sostituirlo?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="837"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation>Sono supportati solo caratteri tradizionali e cinesi, oltre che alcuni simboli</translation>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="296"/>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <source>Rename</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="314"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="317"/>
        <source>Open with</source>
        <translation>Apri con</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="321"/>
        <location filename="../src/source/tree/compressview.cpp" line="500"/>
        <source>Select default program</source>
        <translation>Scegli il programma di default</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>Eliminerà definitivamente il(i) file in questione. Sicuro di voler continuare?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <location filename="../src/source/tree/compressview.cpp" line="474"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="364"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="475"/>
        <source>Add</source>
        <comment>button</comment>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="473"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>Desideri aggiungere l&apos;archivio alla lista oppure aprirlo in una nuova finestra?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="476"/>
        <source>Open in new window</source>
        <translation>Apri in una nuova finestra</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="312"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>Le modifiche agli archivi con questa estensione non sono supportati. Convertilo prima in un formato gestibile per salvare le modifiche effettuate.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Convert the format to:</source>
        <translation>Converti nel formato:</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="344"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="345"/>
        <source>Convert</source>
        <comment>button</comment>
        <translation>Converti</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>elemento(i)</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="87"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Estrazione fallita</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="100"/>
        <source>Damaged file, unable to extract</source>
        <translation>File danneggiato, impossibile procedere con l&apos;estrazione</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="105"/>
        <source>Retry</source>
        <comment>button</comment>
        <translation>Riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="108"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Trascina qui un file o una cartella</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Seleziona file</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>The archive is damaged</source>
        <translation>L&apos;archivio è danneggiato</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="528"/>
        <source>Open as read-only</source>
        <translation>Apri in sola lettura</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="529"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Caricamento, attendere prego...</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <location filename="../src/main.cpp" line="61"/>
        <source>Archive Manager</source>
        <translation>Gestore Archivi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="62"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>Archive Manager è un&apos;applicazione veloce e leggera per la creazione e l&apos;estrazione di archivi.
Localizzazione italiana a cura di Massimo A. Carofano.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="179"/>
        <source>Open file</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="180"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="276"/>
        <location filename="../src/source/mainwindow.cpp" line="286"/>
        <source>Create New Archive</source>
        <translation>Crea nuovo Archivio</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="334"/>
        <source>Converting</source>
        <translation>Conversione</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="341"/>
        <source>Updating comments</source>
        <translation>Aggiornamento commenti</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="2071"/>
        <location filename="../src/source/mainwindow.cpp" line="2097"/>
        <location filename="../src/source/mainwindow.cpp" line="2122"/>
        <source>Plugin error</source>
        <translation>Errore plugin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1284"/>
        <source>Adding successful</source>
        <translation>Inserimento riuscito</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2146"/>
        <source>No data in it</source>
        <translation>Nessuna data</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1521"/>
        <source>Adding canceled</source>
        <translation>Aggiunta annullata</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1623"/>
        <source>Adding failed</source>
        <translation>Aggiunta fallits</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1676"/>
        <source>Extraction failed: the file name is too long</source>
        <translation>Estrazione non riuscita: il nome del file è troppo lungo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1703"/>
        <location filename="../src/source/mainwindow.cpp" line="2142"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation>Creazione fallita di &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1825"/>
        <source>Open failed: the file name is too long</source>
        <translation>Apertura fallita: il nome del file è troppo lungo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2044"/>
        <source>Compression successful</source>
        <translation>Compressione riuscita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2050"/>
        <source>The file name is too long, so the first 60 characters have been intercepted as the file name.</source>
        <translation>Il nome del file è troppo lungo, quindi i primi 60 caratteri sono stati intercettati come nome del file.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2079"/>
        <location filename="../src/source/mainwindow.cpp" line="2150"/>
        <source>Insufficient disk space</source>
        <translation>Spazio su fisco insufficiente</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <location filename="../src/source/mainwindow.cpp" line="2130"/>
        <source>Some volumes are missing</source>
        <translation>Alcuni volumi non sono presenti</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2134"/>
        <source>Wrong password, please retry</source>
        <translation>Password errata, riprova</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2138"/>
        <location filename="../src/source/mainwindow.cpp" line="2162"/>
        <source>The file name is too long. Keep the name within 60 characters please.</source>
        <translation>Il nome del file è troppo lungo. Mantieni il nome entro 60 caratteri per favore.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2159"/>
        <source>Conversion failed</source>
        <translation>Conversione fallita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2297"/>
        <source>Select file</source>
        <translation>Seleziona file</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3167"/>
        <source>Enter up to %1 characters</source>
        <translation>Inserisci più di %1 caratteri</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3043"/>
        <source>File info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Do you want to delete the archive?</source>
        <translation>Desideri eliminare l&apos;archivio?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="533"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1 è stata modificata sul Disco, importala nuovamente.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="75"/>
        <source>Archive Manager</source>
        <translation>Gestore Archivi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Non hai l&apos;autorizzazione per salvare il file qui, scegli un altro percorso e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="299"/>
        <source>Adding files to %1</source>
        <translation>Aggiunta file in %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Compressing</source>
        <translation>Compressione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="313"/>
        <source>Extracting</source>
        <translation>Estrazione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="320"/>
        <source>Deleting</source>
        <translation>Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="493"/>
        <location filename="../src/source/mainwindow.cpp" line="2867"/>
        <source>Loading, please wait...</source>
        <translation>Caricamento, attendere prego...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>Sicuro di voler interrompere l&apos;operazione in corso?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1290"/>
        <location filename="../src/source/mainwindow.cpp" line="1417"/>
        <location filename="../src/source/mainwindow.cpp" line="1433"/>
        <source>Updating, please wait...</source>
        <translation>Aggiornamento in corso, attendere prego...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1698"/>
        <source>File name too long</source>
        <translation>Il nome file è troppo lungo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2075"/>
        <source>Failed to create file</source>
        <translation>Creazione file fallita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2068"/>
        <source>Compression failed</source>
        <translation>Compressione fallita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Sostituisci</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2471"/>
        <source>Find directory</source>
        <translation>Trova percorso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2094"/>
        <source>Open failed</source>
        <translation>Apertura fallita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1619"/>
        <location filename="../src/source/mainwindow.cpp" line="1693"/>
        <location filename="../src/source/mainwindow.cpp" line="1768"/>
        <location filename="../src/source/mainwindow.cpp" line="1823"/>
        <location filename="../src/source/mainwindow.cpp" line="2105"/>
        <source>Wrong password</source>
        <translation>Password errata</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="645"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation>Il formato del file non è supportato dal Gestore Archivi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="136"/>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="503"/>
        <location filename="../src/source/mainwindow.cpp" line="536"/>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <location filename="../src/source/mainwindow.cpp" line="612"/>
        <location filename="../src/source/mainwindow.cpp" line="652"/>
        <location filename="../src/source/mainwindow.cpp" line="1316"/>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <location filename="../src/source/mainwindow.cpp" line="2729"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="327"/>
        <source>Renaming</source>
        <translation>Ridenominazione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="441"/>
        <location filename="../src/source/mainwindow.cpp" line="603"/>
        <source>You do not have permission to load %1</source>
        <translation>Non hai l&apos;autorizzazione per caricare %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="569"/>
        <location filename="../src/source/mainwindow.cpp" line="1393"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="597"/>
        <source>No such file or directory</source>
        <translation>Nessun file o percorso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1332"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Estrazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1542"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation>Estrazione annullata</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1688"/>
        <location filename="../src/source/mainwindow.cpp" line="1763"/>
        <location filename="../src/source/mainwindow.cpp" line="2101"/>
        <location filename="../src/source/mainwindow.cpp" line="2126"/>
        <source>The archive is damaged</source>
        <translation>L&apos;archivio è danneggiato</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2048"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Estrazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2054"/>
        <source>Conversion successful</source>
        <translation>Conversione riuscita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2083"/>
        <source>The compressed volumes already exist</source>
        <translation>I volumi compressi esistono già</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2119"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Estrazione fallita</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2289"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2293"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2301"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2309"/>
        <source>Display shortcuts</source>
        <translation>Visualizza scorciatoie</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2321"/>
        <source>Shortcuts</source>
        <translation>Scorciatoie</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2399"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>Il nome è il medesimo dell&apos;archivio compresso, per cortesia utilizza un nome differente</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2407"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Esiste già un file con lo stesso nome, desideri sostituirlo?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2550"/>
        <source>You cannot add the archive to itself</source>
        <translation>Non puoi aggiungere l&apos;archivio al tuo lavoro</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2565"/>
        <source>You cannot add files to archives in this file type</source>
        <translation>Non puoi aggiungere elementi ad un archivio di questo tipo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2889"/>
        <source>Update</source>
        <comment>button</comment>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3067"/>
        <source>Basic info</source>
        <translation>Info base</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3083"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3084"/>
        <source>Type</source>
        <translation>Tipologia</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3085"/>
        <source>Location</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Time created</source>
        <translation>Data creazione</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3087"/>
        <source>Time accessed</source>
        <translation>Data ultimo accesso</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3088"/>
        <source>Time modified</source>
        <translation>Data modifica</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3098"/>
        <source>Archive</source>
        <translation>Archivio</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3129"/>
        <source>Comment</source>
        <translation>Commenti</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="642"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Controlla il tipo di associazione nelle impostazioni del Gestore Archivi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2278"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>L&apos;archivio è stato modificato sul Disco, importalo nuovamente.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Percorso</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Applicazione</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Immagine</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Archivio</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>Eseguibile</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>File di backup</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Apri con</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Add other programs</source>
        <translation>Aggiungi altri programmi</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="301"/>
        <source>Set as default</source>
        <translation>Imposta come default</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="304"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="308"/>
        <source>Recommended Applications</source>
        <translation>App raccomandate</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="310"/>
        <source>Other Applications</source>
        <translation>Altre App</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>File crittografato, inserisci la password</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation>Percorso corrente;</translation>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation>Torna a: %1</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>%1 operazione(i) in corso</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Attività</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>Estrazione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>Sicuro di voler interrompere l&apos;estrazione?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="325"/>
        <location filename="../src/source/page/progresspage.cpp" line="328"/>
        <location filename="../src/source/page/progresspage.cpp" line="331"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Velocità</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="59"/>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="160"/>
        <source>Calculating...</source>
        <translation>Calcolo in corso...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="61"/>
        <location filename="../src/source/page/progresspage.cpp" line="335"/>
        <location filename="../src/source/page/progresspage.cpp" line="337"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Velocità</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="341"/>
        <location filename="../src/source/page/progresspage.cpp" line="343"/>
        <source>Speed</source>
        <comment>rename</comment>
        <translation>Velocità</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="65"/>
        <location filename="../src/source/page/progresspage.cpp" line="355"/>
        <location filename="../src/source/page/progresspage.cpp" line="357"/>
        <location filename="../src/source/page/progresspage.cpp" line="359"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Velocità</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="69"/>
        <location filename="../src/source/page/progresspage.cpp" line="347"/>
        <location filename="../src/source/page/progresspage.cpp" line="349"/>
        <location filename="../src/source/page/progresspage.cpp" line="351"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Velocità</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="72"/>
        <location filename="../src/source/page/progresspage.cpp" line="321"/>
        <source>Time left</source>
        <translation>Tempo rimanente</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="131"/>
        <source>Compressing</source>
        <translation>Compressione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="133"/>
        <source>Deleting</source>
        <translation>Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="135"/>
        <source>Renaming</source>
        <translation>Ridenominazione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="137"/>
        <source>Converting</source>
        <translation>Conversione</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="139"/>
        <location filename="../src/source/page/progresspage.cpp" line="158"/>
        <source>Updating the comment...</source>
        <translation>Aggiornamento commenti...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="141"/>
        <source>Extracting</source>
        <translation>Estrazione in corso</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="152"/>
        <location filename="../src/source/page/progresspage.cpp" line="189"/>
        <location filename="../src/source/page/progresspage.cpp" line="375"/>
        <source>Pause</source>
        <comment>button</comment>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="188"/>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="371"/>
        <source>Continue</source>
        <comment>button</comment>
        <translation>Continua</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="404"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="393"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation>Sicuro di voler interrompere l&apos;estrazione?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="395"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation>Sicuro di voler annullare l&apos;eliminazione?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="391"/>
        <location filename="../src/source/page/progresspage.cpp" line="397"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>Sicuro di voler interrompere la compressione?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="399"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>Sicuro di voler interrompere la conversione?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Data modifica</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Tipologia</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2886"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>%1 modificato. Desideri salvare le modifiche nell&apos;archivio?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>Generali</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Estrazione</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Crea automaticamente una cartella contenente i file estratti</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Mostra file estratti al termine</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Gestione file</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Elimina i file dopo la compressione</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>File associati</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Tipo file</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="214"/>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <source>Skip</source>
        <comment>button</comment>
        <translation>Salta</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Merge</source>
        <comment>button</comment>
        <translation>Unisci</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Esiste già un file con lo stesso nome, desideri sostituirlo?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="215"/>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <source>Replace</source>
        <comment>button</comment>
        <translation>Sostituisci</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="483"/>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="484"/>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation>Esiste già un file con lo stesso nome nella cartella di destinazione, sostituirlo?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="218"/>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <source>Apply to all</source>
        <translation>Applica a tutti</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="557"/>
        <source>Rename</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="608"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="609"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="619"/>
        <source>The name already exists</source>
        <translation>Il nome esiste già.</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Cartella corrente</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Annulla Tutto</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <comment>button</comment>
        <translation>Seleziona Tutto</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Raccomandato</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Estrai archivi in</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Un&apos;altra cartella</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>Desktop</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Elimina gli archivi dopo l&apos;estrazione</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Chiedi ogni volta</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>Compression successful</source>
        <translation>Compressione riuscita</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="89"/>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="92"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3324"/>
        <location filename="../src/source/mainwindow.cpp" line="3381"/>
        <source>Open file</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3327"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3386"/>
        <source>File info</source>
        <translation>Info</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="75"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="87"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="116"/>
        <source>Extract to:</source>
        <translation>Estrai in:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="117"/>
        <source>Extract</source>
        <comment>button</comment>
        <translation>Estrai</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="193"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>Il percorso di estrazione di default non esiste, riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="195"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Non hai l&apos;autorizzazione per salvare il file qui, scegli un altro percorso e riprova</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="199"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="213"/>
        <source>Find directory</source>
        <translation>Trova percorso</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>You cannot add the archive to itself</source>
        <translation>Non puoi aggiungere l&apos;archivio al tuo lavoro</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="401"/>
        <source>OK</source>
        <comment>button</comment>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="627"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Estrai</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Extract to current directory</source>
        <translation>Estrai nella cartella corrente</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="631"/>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <source>Rename</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="638"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="645"/>
        <source>Open with</source>
        <translation>Apri con</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="649"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="790"/>
        <source>Select default program</source>
        <translation>Scegli il programma di default</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Cancel</source>
        <comment>button</comment>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Confirm</source>
        <comment>button</comment>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="700"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>Desideri eliminare i file selezionati?</translation>
    </message>
</context>
</TS>