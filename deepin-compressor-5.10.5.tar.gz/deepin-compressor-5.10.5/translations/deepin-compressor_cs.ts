<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.1">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="448"/>
        <source>Add files to the current archive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="453"/>
        <source>Use password</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>Aktualizace komentáře…</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="76"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>Please add files</source>
        <translation>Přidejte soubory</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="141"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>New Archive</source>
        <translation>Nový archiv</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="202"/>
        <source>Advanced Options</source>
        <translation>Pokročilé volby</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="206"/>
        <source>Compression method</source>
        <translation>Metoda komprese</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="209"/>
        <source>Encrypt the archive</source>
        <translation>Zašifrovat archiv</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Encrypt the file list too</source>
        <translation>Zašifrovat také seznam souborů</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="213"/>
        <source>Split to volumes</source>
        <translation>Rozdělit na části</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="215"/>
        <source>Comment</source>
        <translation>Komentář</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="217"/>
        <source>Compress</source>
        <translation>Zkomprimovat</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Store</source>
        <translation>Úložiště</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fastest</source>
        <translation>Nejrychlejší</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fast</source>
        <translation>Rychlé</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Normal</source>
        <translation>Normální</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Good</source>
        <translation>Dobrá</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Best</source>
        <translation>Nejlepší</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="244"/>
        <source>Support zip, 7z type only</source>
        <translation>Podpora pro formát ZIP, pouze typ 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="247"/>
        <source>Support 7z type only</source>
        <translation>Podpora pouze pro typ 7z</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="259"/>
        <source>Enter up to %1 characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="280"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="281"/>
        <source>Save to</source>
        <translation>Uložit do</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="469"/>
        <source>Invalid file name</source>
        <translation>Neplatný název souboru</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="475"/>
        <source>Please enter the path</source>
        <translation>Zadejte popis umístění</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="480"/>
        <source>The path does not exist, please retry</source>
        <translation>Daný popis umístění neexistuje – zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="485"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nemáte oprávnění ukládat sem soubory. Změňte umístění a zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="493"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Příliš mnoho svazků – přejděte jinam a zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="502"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="530"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="508"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="537"/>
        <source>You do not have permission to compress %1</source>
        <translation>Nemáte oprávnění pro zkomprimování %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="563"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="671"/>
        <source>Total size: %1</source>
        <translation>Celková velikost: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="691"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="699"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Už existuje jiný soubor se stejným názvem. Nahradit ho?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Replace</source>
        <translation>Nahradit</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="784"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="286"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="300"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="303"/>
        <source>Open with</source>
        <translation>Otevřít s</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <location filename="../src/source/tree/compressview.cpp" line="408"/>
        <source>Select default program</source>
        <translation>Vyberte výchozí program</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>Toto soubory natrvalo smaže. Opravdu chcete pokračovat?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <location filename="../src/source/tree/compressview.cpp" line="382"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="381"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>Chcete archiv přidat do seznamu nebo ho otevřít v novém okně?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="383"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="384"/>
        <source>Open in new window</source>
        <translation>Otevřít v novém okně</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="352"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="353"/>
        <source>Convert</source>
        <translation>Převést</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>V případě tohoto typu souboru nejsou změny v archivu podporovány. Pro uložení změn převeďte do jiného formátu archivu.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="328"/>
        <source>Convert the format to:</source>
        <translation>Převést formát na:</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>položka/y</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="76"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Rozbalení se nezdařilo</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="84"/>
        <source>Damaged file, unable to extract</source>
        <translation>Poškozený soubor. Nelze rozbalit</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="89"/>
        <source>Retry</source>
        <translation>Zkusit znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="92"/>
        <source>Back</source>
        <translation>Zpět</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Sem přetáhněte soubor nebo složku</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Vybrat soubor</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="522"/>
        <source>The archive is damaged</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>Open as read-only</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="526"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Načítání – čekejte prosím…</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="54"/>
        <location filename="../src/main.cpp" line="55"/>
        <source>Archive Manager</source>
        <translation>Správce archivů</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="56"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>Správce archivů je rychlá a na systémové prostředky nenáročná aplikace pro vytváření a rozbalování archivů.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="171"/>
        <location filename="../src/source/mainwindow.cpp" line="190"/>
        <location filename="../src/source/mainwindow.cpp" line="442"/>
        <source>Open file</source>
        <translation>Otevřít soubor</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="172"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="296"/>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Create New Archive</source>
        <translation>Vytvořit nový archiv</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="347"/>
        <source>Converting</source>
        <translation>Převádí se</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="354"/>
        <source>Updating comments</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="2062"/>
        <location filename="../src/source/mainwindow.cpp" line="2084"/>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <source>Plugin error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1317"/>
        <source>Adding successful</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2133"/>
        <source>No data in it</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1539"/>
        <source>Adding canceled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1634"/>
        <source>Adding failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1704"/>
        <location filename="../src/source/mainwindow.cpp" line="2129"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2038"/>
        <source>Compression successful</source>
        <translation>Úspěšně zkomprimováno</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2070"/>
        <location filename="../src/source/mainwindow.cpp" line="2137"/>
        <source>Insufficient disk space</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2096"/>
        <location filename="../src/source/mainwindow.cpp" line="2117"/>
        <source>Some volumes are missing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2121"/>
        <source>Wrong password, please retry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2291"/>
        <source>Select file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Update</source>
        <translation>Aktualizace</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Enter up to %1 characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="195"/>
        <location filename="../src/source/mainwindow.cpp" line="2962"/>
        <source>File info</source>
        <translation>Informace o souboru</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Do you want to delete the archive?</source>
        <translation>Opravdu chcete archiv smazat?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="555"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1 byl mezitím změněn na disku. Otevřete ho znovu.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="73"/>
        <source>Archive Manager</source>
        <translation>Správce archivů</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="558"/>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="674"/>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <location filename="../src/source/mainwindow.cpp" line="2719"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nemáte oprávnění ukládat sem soubory. Změňte umístění a zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="319"/>
        <source>Adding files to %1</source>
        <translation>Přidávají se soubory do %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="326"/>
        <source>Compressing</source>
        <translation>Komprimuje se</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="333"/>
        <source>Extracting</source>
        <translation>Rozbaluje se</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="340"/>
        <source>Deleting</source>
        <translation>Maže se</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="445"/>
        <source>Back</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="515"/>
        <location filename="../src/source/mainwindow.cpp" line="2786"/>
        <source>Loading, please wait...</source>
        <translation>Načítání – čekejte prosím…</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>Opravdu chcete probíhající úlohu zastavit?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1323"/>
        <location filename="../src/source/mainwindow.cpp" line="1451"/>
        <source>Updating, please wait...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1699"/>
        <location filename="../src/source/mainwindow.cpp" line="2125"/>
        <source>File name too long</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2066"/>
        <source>Failed to create file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2059"/>
        <source>Compression failed</source>
        <translation>Komprimace se nezdařila</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2459"/>
        <source>Find directory</source>
        <translation>Najít složku</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2081"/>
        <source>Open failed</source>
        <translation>Otevření se nezdařilo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1630"/>
        <location filename="../src/source/mainwindow.cpp" line="1694"/>
        <location filename="../src/source/mainwindow.cpp" line="1769"/>
        <location filename="../src/source/mainwindow.cpp" line="1824"/>
        <location filename="../src/source/mainwindow.cpp" line="2092"/>
        <source>Wrong password</source>
        <translation>Chybné heslo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="665"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <source>You do not have permission to load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <source>No such file or directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1365"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Rozbalení úspěšné</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1560"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1689"/>
        <location filename="../src/source/mainwindow.cpp" line="1764"/>
        <location filename="../src/source/mainwindow.cpp" line="2088"/>
        <location filename="../src/source/mainwindow.cpp" line="2113"/>
        <source>The archive is damaged</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1711"/>
        <source>Extraction failed</source>
        <comment>提取失败</comment>
        <translation>Rozbalení se nezdařilo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2042"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Rozbalení úspěšné</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2045"/>
        <source>Conversion successful</source>
        <translation>Převedení úspěšné</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2106"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Rozbalení se nezdařilo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2283"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2287"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2295"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2303"/>
        <source>Display shortcuts</source>
        <translation>Zobrazit klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2315"/>
        <source>Shortcuts</source>
        <translation>Klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2381"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Už existuje jiný soubor se stejným názvem. Nahradit ho?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Replace</source>
        <translation>Nahradit</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2542"/>
        <source>You cannot add the archive to itself</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <source>You cannot add files to archives in this file type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2986"/>
        <source>Basic info</source>
        <translation>Základní informace</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3002"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3003"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3004"/>
        <source>Location</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3005"/>
        <source>Time created</source>
        <translation>Okamžik vytvoření</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3006"/>
        <source>Time accessed</source>
        <translation>Okamžik přístupu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3007"/>
        <source>Time modified</source>
        <translation>Čas změny</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3017"/>
        <source>Archive</source>
        <translation>Archiv</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3048"/>
        <source>Comment</source>
        <translation>Komentář</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="662"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Zkontrolujte přiřazení typu souborů v nastavení Správce archivů</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>Archiv byl mezitím změněn na disku. Otevřete ho znovu.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Složka</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Aplikace</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Zvuk</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Archiv</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>Spustitelný</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>Záložní soubor</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>Neznámý</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Otevřít s</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="299"/>
        <source>Add other programs</source>
        <translation>Přidat ostatní programy</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Set as default</source>
        <translation>Nastavit jako výchozí</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="302"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="307"/>
        <source>Recommended Applications</source>
        <translation>Doporučené aplikace</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="309"/>
        <source>Other Applications</source>
        <translation>Ostatní aplikace</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>Zašifrovaný soubor – zadejte heslo</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>%1 úkol(y) probíhá</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Úloha</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>Rozbaluje se</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>Opravdu chcete rozbalování zastavit?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="306"/>
        <location filename="../src/source/page/progresspage.cpp" line="309"/>
        <location filename="../src/source/page/progresspage.cpp" line="312"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="144"/>
        <source>Calculating...</source>
        <translation>Počítá se…</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="316"/>
        <location filename="../src/source/page/progresspage.cpp" line="318"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="330"/>
        <location filename="../src/source/page/progresspage.cpp" line="332"/>
        <location filename="../src/source/page/progresspage.cpp" line="334"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="322"/>
        <location filename="../src/source/page/progresspage.cpp" line="324"/>
        <location filename="../src/source/page/progresspage.cpp" line="326"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Rychlost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="302"/>
        <source>Time left</source>
        <translation>Zbývající čas</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="117"/>
        <source>Compressing</source>
        <translation>Komprimuje se</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="119"/>
        <source>Deleting</source>
        <translation>Maže se</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="121"/>
        <source>Converting</source>
        <translation>Převádí se</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="123"/>
        <location filename="../src/source/page/progresspage.cpp" line="142"/>
        <source>Updating the comment...</source>
        <translation>Aktualizace komentáře…</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="125"/>
        <source>Extracting</source>
        <translation>Rozbaluje se</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="172"/>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="368"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="370"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="136"/>
        <location filename="../src/source/page/progresspage.cpp" line="173"/>
        <location filename="../src/source/page/progresspage.cpp" line="350"/>
        <source>Pause</source>
        <translation>Pozastavit</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="346"/>
        <source>Continue</source>
        <translation>Pokračovat</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="366"/>
        <location filename="../src/source/page/progresspage.cpp" line="372"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>Opravdu chcete komprimaci zastavit?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="374"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>Opravdu chcete převádění zastavit?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Čas změny</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2805"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>%1 se změnilo. Chcete uložit změny do archivu?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="500"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Rozbalení</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Pro vícero rozbalených souborů automaticky vytvořit složku</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Po dokončení ukázat rozbalené soubory</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Správa souboru</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Po zkomprimování smazat zdrojové soubory</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>Přiřazené soubory</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Typ souboru</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="501"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Už existuje jiný soubor se stejným názvem. Nahradit ho?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="202"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <source>Skip</source>
        <translation>Přeskočit</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="200"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="203"/>
        <source>Merge</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Replace</source>
        <translation>Nahradit</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <source>Apply to all</source>
        <translation>Použít na vše</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="403"/>
        <source>Open file</source>
        <translation>Otevřít soubor</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="409"/>
        <source>Back</source>
        <translation>Zpět</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Stávající složka</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Vyprázdnit vše</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Doporučeno</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Rozbalit archivy do</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Jiná složka</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>Plocha</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Po rozbalení smazat archivy</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Nikdy</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Ptát se na potvrzení</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Vždy</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="74"/>
        <source>Compression successful</source>
        <translation>Úspěšně zkomprimováno</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="82"/>
        <source>Back</source>
        <translation>Zpět</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="120"/>
        <source>Extract</source>
        <translation>Rozbalit</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="74"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="85"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="119"/>
        <source>Extract to:</source>
        <translation>Rozbalit do:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="194"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>Výchozí popis umístění pro rozbalení neexistuje – zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="196"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nemáte oprávnění ukládat sem soubory. Změňte umístění a zkuste to znovu</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="214"/>
        <source>Find directory</source>
        <translation>Najít složku</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="200"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>You cannot add the archive to itself</source>
        <translation>Není možné přidat archiv do sama sebe</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="615"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Rozbalit</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="617"/>
        <source>Extract to current directory</source>
        <translation>Rozbalit do stávající složky</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="619"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="622"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Open with</source>
        <translation>Otevřít s</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="734"/>
        <source>Select default program</source>
        <translation>Vyberte výchozí program</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Confirm</source>
        <translation>Potvrdit</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>Opravdu chcete označené soubory smazat?</translation>
    </message>
</context>
</TS>