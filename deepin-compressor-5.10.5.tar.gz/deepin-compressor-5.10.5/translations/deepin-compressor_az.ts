<?xml version="1.0" ?><!DOCTYPE TS><TS language="az" version="2.1">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="448"/>
        <source>Add files to the current archive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="453"/>
        <source>Use password</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>%1 orijinal faylı mövcud deyil, lütfən, yoxlayın və yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 diskdə mövcud deyil, lütfən, yoxlayın və yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation>Sizin %1 sıxmağa icazəniz yoxdur</translation>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>Şərh yenilənir...</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="76"/>
        <source>Next</source>
        <translation>Növbəti</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>Please add files</source>
        <translation>Fayllar əlavə edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="141"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>New Archive</source>
        <translation>Yeni arxiv</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="202"/>
        <source>Advanced Options</source>
        <translation>Əlavə seçimlər</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="206"/>
        <source>Compression method</source>
        <translation>Sıxılma üsulu</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="209"/>
        <source>Encrypt the archive</source>
        <translation>Arxivi şifrələmək</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Encrypt the file list too</source>
        <translation>Fayl siyahısını da şifrələmək</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="213"/>
        <source>Split to volumes</source>
        <translation>Həcmlərə bölmək</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="215"/>
        <source>Comment</source>
        <translation>Şərh</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="217"/>
        <source>Compress</source>
        <translation>Sıxmaq</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Store</source>
        <translation>Saxlamaq</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fastest</source>
        <translation>Ən tez</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fast</source>
        <translation>Sürətli</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Good</source>
        <translation>Yaxşı</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Best</source>
        <translation>Ən yaxşı</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="244"/>
        <source>Support zip, 7z type only</source>
        <translation>Yalnız zip, 7z növləri dəstəklənir</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="247"/>
        <source>Support 7z type only</source>
        <translation>Yalnız 7z növü dəstəklənir</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="259"/>
        <source>Enter up to %1 characters</source>
        <translation>%1 və daha çox işarə daxil edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="280"/>
        <source>Name</source>
        <translation>Adı</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="281"/>
        <source>Save to</source>
        <translation>Burada saxlamaq</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="469"/>
        <source>Invalid file name</source>
        <translation>Səhv fayl adı</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="475"/>
        <source>Please enter the path</source>
        <translation>Lütfən yolu daxil edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="480"/>
        <source>The path does not exist, please retry</source>
        <translation>Yol yoxdur, lütfən, təkrarlayın</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="485"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Faylları burada saxlamağa icazəniz yoxdur, dəyişdirin və yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="493"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Həddindən çox həcmlər, lütfən, dəyişin və yrnidən təkrar edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="502"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="530"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>Diskdə %1 mövcud deyil, lütfən, yoxlayın və təkrar edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="508"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="537"/>
        <source>You do not have permission to compress %1</source>
        <translation>%1 sıxmaöa icazəniz yoxdur</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>%1 faylının əsli mövcud deyil,lütfən, yoxlayın və təkrar edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="563"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="671"/>
        <source>Total size: %1</source>
        <translation>Ümumi ölçü: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="691"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>Ad, sıxışdırılmış arxiv adı ilə eynidir, lütən başqasını seçin</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="699"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Bu adla başqa bir fayl mövcuddur, o əvəz edilsin?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Replace</source>
        <translation>Əvəz etmək</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="784"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation>Yalnız Çin və İngilis işarələri və bəzi simvollar dəstəklənir</translation>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="286"/>
        <source>Open</source>
        <translation>Açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="300"/>
        <source>Delete</source>
        <translation>Silmək</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="303"/>
        <source>Open with</source>
        <translation>Bununla açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <location filename="../src/source/tree/compressview.cpp" line="408"/>
        <source>Select default program</source>
        <translation>Standart proqramı seçin</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>Bununla fayl(lar) birdəfəlik silinəcək. Davam etmək istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <location filename="../src/source/tree/compressview.cpp" line="382"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="381"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>Siz arxivi siyahıya əlavə etmək yoxsa onu yeni pəncərədə açmaq istəyirsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="383"/>
        <source>Add</source>
        <translation>Əlavə etmək</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="384"/>
        <source>Open in new window</source>
        <translation>Ueni pəncərədə açmaq</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="352"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="353"/>
        <source>Convert</source>
        <translation>Çevirmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>Bu fayl növündəki arxivlərdə dəyişiklik etmək dəstəklənmir. Dəyişiklikləri saxlamaq üçün arxivin formatını dəyişin.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="328"/>
        <source>Convert the format to:</source>
        <translation>Bu formata çevirmək:</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>element(lər)</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="76"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Çıxarıla bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="84"/>
        <source>Damaged file, unable to extract</source>
        <translation>Pozulmuş fayl, çıxarıla bilmir</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="89"/>
        <source>Retry</source>
        <translation>Təkrar</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="92"/>
        <source>Back</source>
        <translation>Geriyə</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Faylı və ya qovluğu buraya atın</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Fayl seçimi</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="522"/>
        <source>The archive is damaged</source>
        <translation>Arxiv zədələnib</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>Open as read-only</source>
        <translation>Yalnız oxumaq üçün açmaq</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="526"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Yüklənir, lütfən, gözləyin</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="54"/>
        <location filename="../src/main.cpp" line="55"/>
        <source>Archive Manager</source>
        <translation>Arxiv meneceri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="56"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>Arxiv Meneceri faylları arxivləmək və arxivdən çıxartmaq üçün sürətli və yüngül tətbiqdir.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="171"/>
        <location filename="../src/source/mainwindow.cpp" line="190"/>
        <location filename="../src/source/mainwindow.cpp" line="442"/>
        <source>Open file</source>
        <translation>Faylı açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="172"/>
        <source>Settings</source>
        <translation>Ayarlar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="296"/>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Create New Archive</source>
        <translation>Yeni arxiv yaratmaq</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="347"/>
        <source>Converting</source>
        <translation>Çevrilir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="354"/>
        <source>Updating comments</source>
        <translation>Şərhlər yenilənir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="2062"/>
        <location filename="../src/source/mainwindow.cpp" line="2084"/>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <source>Plugin error</source>
        <translation>Qoşma xətası</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1317"/>
        <source>Adding successful</source>
        <translation>Uğurla əlavə olunur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2133"/>
        <source>No data in it</source>
        <translation>Bunda verilən yoxdur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1539"/>
        <source>Adding canceled</source>
        <translation>Əlavə edilmə ləğv edildi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1634"/>
        <source>Adding failed</source>
        <translation>Əlavə edilə bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1704"/>
        <location filename="../src/source/mainwindow.cpp" line="2129"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation>&quot;%1&quot; yaradıla bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2038"/>
        <source>Compression successful</source>
        <translation>Sıxılma uğurlu oldu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2070"/>
        <location filename="../src/source/mainwindow.cpp" line="2137"/>
        <source>Insufficient disk space</source>
        <translation>Yetərsiz disk sahəsi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2096"/>
        <location filename="../src/source/mainwindow.cpp" line="2117"/>
        <source>Some volumes are missing</source>
        <translation>Bəzi həcmlər mövcud deyil</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2121"/>
        <source>Wrong password, please retry</source>
        <translation>Səhv şifrə, lütfən təkrar edin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2291"/>
        <source>Select file</source>
        <translation>Faylı seçin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Update</source>
        <translation>Yeniləmək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Enter up to %1 characters</source>
        <translation>%1 və daha çox işarə daxil edin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="195"/>
        <location filename="../src/source/mainwindow.cpp" line="2962"/>
        <source>File info</source>
        <translation>Fayl məlumatı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Do you want to delete the archive?</source>
        <translation>Bu arxivi silmək istəyirsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="555"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1, bu diskdə dəyişdirildi, lütfən onu yenidən idxal edin.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="73"/>
        <source>Archive Manager</source>
        <translation>Arxiv Meneceri</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="558"/>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="674"/>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <location filename="../src/source/mainwindow.cpp" line="2719"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Faylları burada saxlamağa icazəniz yoxdur, dəyişdirin və yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="319"/>
        <source>Adding files to %1</source>
        <translation>Fayllar %1-ə/a əlavə olunur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="326"/>
        <source>Compressing</source>
        <translation>Sıxılır</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="333"/>
        <source>Extracting</source>
        <translation>Çıxarılır</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="340"/>
        <source>Deleting</source>
        <translation>Silinir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="445"/>
        <source>Back</source>
        <translation>Geriyə</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="515"/>
        <location filename="../src/source/mainwindow.cpp" line="2786"/>
        <source>Loading, please wait...</source>
        <translation>Yüklənir, lütfən, gözləyin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>Davam edən əməliyyatı dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1323"/>
        <location filename="../src/source/mainwindow.cpp" line="1451"/>
        <source>Updating, please wait...</source>
        <translation>Yenilənir, lütfən, gözləyin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1699"/>
        <location filename="../src/source/mainwindow.cpp" line="2125"/>
        <source>File name too long</source>
        <translation>Fayl adı çox uzundur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2066"/>
        <source>Failed to create file</source>
        <translation>Fayl yaradıla bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2059"/>
        <source>Compression failed</source>
        <translation>Sıxılma alınmadı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2459"/>
        <source>Find directory</source>
        <translation>Qovluğu tapmaq</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2081"/>
        <source>Open failed</source>
        <translation>Açıla bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1630"/>
        <location filename="../src/source/mainwindow.cpp" line="1694"/>
        <location filename="../src/source/mainwindow.cpp" line="1769"/>
        <location filename="../src/source/mainwindow.cpp" line="1824"/>
        <location filename="../src/source/mainwindow.cpp" line="2092"/>
        <source>Wrong password</source>
        <translation>Səhv şifrə</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="665"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation>Fayl formatı Arxiv Meneceri tərəfindən dəstəklənmir</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <source>You do not have permission to load %1</source>
        <translation>%1 yükləməyə icazəniz yoxdur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <source>No such file or directory</source>
        <translation>Belə fayl və ya qovluq yoxdur</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1365"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Uğurla çıxarıldı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1560"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation>Çıxarılma ləğv edildi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1689"/>
        <location filename="../src/source/mainwindow.cpp" line="1764"/>
        <location filename="../src/source/mainwindow.cpp" line="2088"/>
        <location filename="../src/source/mainwindow.cpp" line="2113"/>
        <source>The archive is damaged</source>
        <translation>Arxiv zədələnib</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1711"/>
        <source>Extraction failed</source>
        <comment>提取失败</comment>
        <translation>Çıxarılma alınmadı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2042"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Uğurla çıxarıldı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2045"/>
        <source>Conversion successful</source>
        <translation>Çevirilmə uğurlu oldu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2106"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Çıxarıla bilmədi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2283"/>
        <source>Close</source>
        <translation>Bağlamaq</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2287"/>
        <source>Help</source>
        <translation>Kömək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2295"/>
        <source>Delete</source>
        <translation>Silmək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2303"/>
        <source>Display shortcuts</source>
        <translation>Qısayolları göstərmək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2315"/>
        <source>Shortcuts</source>
        <translation>Qısayollar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2381"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation>Ad, sıxışdırılmış arxiv adı ilə eynidir, lütən başqasını seçin</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Bu adla başqa bir fayl mövcuddur, o əvəz edilsin?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Replace</source>
        <translation>Əvəz etmək</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2542"/>
        <source>You cannot add the archive to itself</source>
        <translation>Arxiv öz saxilinə əlavə edilə bilməz</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <source>You cannot add files to archives in this file type</source>
        <translation>Bu fayl növündəki arxivlərə fayllar əlavə edə bilməzsiniz</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2986"/>
        <source>Basic info</source>
        <translation>Əsas məlumat</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3002"/>
        <source>Size</source>
        <translation>Ölçüsü</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3003"/>
        <source>Type</source>
        <translation>Növ</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3004"/>
        <source>Location</source>
        <translation>Yer</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3005"/>
        <source>Time created</source>
        <translation>Yaradılma vaxtı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3006"/>
        <source>Time accessed</source>
        <translation>Müdaxilə vaxtı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3007"/>
        <source>Time modified</source>
        <translation>Dəyişdirilmə vaxtı</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3017"/>
        <source>Archive</source>
        <translation>Arxiv</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3048"/>
        <source>Comment</source>
        <translation>Şərh</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="662"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Lütfən, fayl əlaqələri növünü Arxiv Meneceri ayarlarında yoxlayın</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>Bu arxiv bu diskdə dəyişdirildi, lütfən onu yenidən idxal edin.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Qovluq</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Tətbiq</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Şəkil</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Arxiv</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>İcra edilə bilən</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Sənəd</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>Ehtiyyat nüsxə faylı</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>Naməlum</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Bununla açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="299"/>
        <source>Add other programs</source>
        <translation>Başqa proqramlar əlavə etmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Set as default</source>
        <translation>Standart kimi təyin etmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="302"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="307"/>
        <source>Recommended Applications</source>
        <translation>Tövsiyyə olunan tətbiqlər</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="309"/>
        <source>Other Applications</source>
        <translation>Başqa tətbiqlər</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>Şifrələnmiş fayl, lütfən, şifrəni daxil edin</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation>Cari yol:</translation>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation>Geriyə: %1</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>%1 tapşırıq(lar) yerinə yetirilir</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Tapşırıq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>Çıxarılır</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>Çıxarılmanı dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="306"/>
        <location filename="../src/source/page/progresspage.cpp" line="309"/>
        <location filename="../src/source/page/progresspage.cpp" line="312"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Sürət</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="144"/>
        <source>Calculating...</source>
        <translation>Hesablanır...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="316"/>
        <location filename="../src/source/page/progresspage.cpp" line="318"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Sürət</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="330"/>
        <location filename="../src/source/page/progresspage.cpp" line="332"/>
        <location filename="../src/source/page/progresspage.cpp" line="334"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Sürət</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="322"/>
        <location filename="../src/source/page/progresspage.cpp" line="324"/>
        <location filename="../src/source/page/progresspage.cpp" line="326"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Sürət</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="302"/>
        <source>Time left</source>
        <translation>Qalan vaxt</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="117"/>
        <source>Compressing</source>
        <translation>Sıxılır</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="119"/>
        <source>Deleting</source>
        <translation>Silinir</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="121"/>
        <source>Converting</source>
        <translation>Çevrilir</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="123"/>
        <location filename="../src/source/page/progresspage.cpp" line="142"/>
        <source>Updating the comment...</source>
        <translation>Şərh yenilənir...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="125"/>
        <source>Extracting</source>
        <translation>Çıxarılır</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="172"/>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="368"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation>Arxivi boşalmasını dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="370"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation>Silinməni dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="136"/>
        <location filename="../src/source/page/progresspage.cpp" line="173"/>
        <location filename="../src/source/page/progresspage.cpp" line="350"/>
        <source>Pause</source>
        <translation>Fasilə</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="346"/>
        <source>Continue</source>
        <translation>Davam etmək</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="366"/>
        <location filename="../src/source/page/progresspage.cpp" line="372"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>Sıxılmanı dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="374"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>Çevrilməni dayandırmaq istədiyinizə əminsiniz?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Adı</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Dəyişdirilmə vaxtı</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Növü</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Ölçüsü</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2805"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>%1 dəyişdirildi. Dəyişiklikləri arxivdə saxlamaq istəyirsiniz?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="500"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>Əsas</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Çıxarılmaq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Çıxarılan çoxsaylı fayllar üçün avtomatik qovluq yaratmaq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Başa çatdıqda çıxarılan faylları göstərmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Fayl İdarəedilməsi</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Sıxıldıqdan sonra faylları silmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>Fayl əlaqələri</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Fayl növü</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="501"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Bu adla başqa bir fayl mövcuddur, o əvəz edilsin?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="202"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <source>Skip</source>
        <translation>Ötürmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="200"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation>Bu adla başqa bir qovluq mövcuddur, o əvəz edilsin?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="203"/>
        <source>Merge</source>
        <translation>Birləşdirmək</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Replace</source>
        <translation>Əvəz etmək</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <source>Apply to all</source>
        <translation>Hamısına tətbiq etmək</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="403"/>
        <source>Open file</source>
        <translation>Faylı açmaq</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="409"/>
        <source>Back</source>
        <translation>Geriyə</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <translation>Hamısını seçmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Cari qoluq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Hamısını silmək</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Tovsiyyə olunan</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Arxivləri buraya çıxartmaq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Başqa qovluq</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>İş Masası</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Çıxarıldıqdan sonra arxiv silinsin</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Heç vaxt</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Tədiq edilməsi soruşulsun</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Həmişə</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="74"/>
        <source>Compression successful</source>
        <translation>Sıxılma uğurlu oldu</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>View</source>
        <translation>Baxış</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="82"/>
        <source>Back</source>
        <translation>Geriyə</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="120"/>
        <source>Extract</source>
        <translation>Çıxartmaq</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="74"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="85"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="119"/>
        <source>Extract to:</source>
        <translation>Buraya çıxartmaq:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="194"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>Standart çıxarılma yolu mövcud deyil, yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="196"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Faylları burada saxlamağa icazəniz yoxdur, dəyişdirin və yenidən cəhd edin</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="214"/>
        <source>Find directory</source>
        <translation>Qovluğu tapmaq</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="200"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>You cannot add the archive to itself</source>
        <translation>Arxivi öz daxilinə əlavə edə bilməzsiniz</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="615"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Çıxartmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="617"/>
        <source>Extract to current directory</source>
        <translation>Cari qovluğa çıxartmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="619"/>
        <source>Open</source>
        <translation>Açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="622"/>
        <source>Delete</source>
        <translation>Silmək</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Open with</source>
        <translation>Bununla açmaq</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="734"/>
        <source>Select default program</source>
        <translation>Standart proqramı seçin</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Cancel</source>
        <translation>İmtina</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Confirm</source>
        <translation>Təsdiq etmək</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>Seçilmiş fayl(lar)ı silmək istəyirsiniz?</translation>
    </message>
</context>
</TS>