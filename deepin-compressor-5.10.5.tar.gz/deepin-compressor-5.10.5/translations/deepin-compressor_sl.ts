<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.1">
<context>
    <name>AppendDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="448"/>
        <source>Add files to the current archive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="453"/>
        <source>Use password</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CalculateSizeThread</name>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="68"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="136"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="70"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="138"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/common/calculatesizethread.cpp" line="79"/>
        <location filename="../src/source/common/calculatesizethread.cpp" line="147"/>
        <source>You do not have permission to compress %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CommentProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="234"/>
        <source>Updating the comment...</source>
        <translation>Posodabljanje komentarja...</translation>
    </message>
</context>
<context>
    <name>CompressPage</name>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="76"/>
        <source>Next</source>
        <translation>Naprej</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>Please add files</source>
        <translation>Dodajte datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresspage.cpp" line="117"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
</context>
<context>
    <name>CompressSettingPage</name>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="141"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="222"/>
        <source>New Archive</source>
        <translation>Nov arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="202"/>
        <source>Advanced Options</source>
        <translation>Napredne možnosti</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="206"/>
        <source>Compression method</source>
        <translation>Način stiskanja</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="209"/>
        <source>Encrypt the archive</source>
        <translation>Šifriraj arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="211"/>
        <source>Encrypt the file list too</source>
        <translation>Šifriraj tudi seznam datotek</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="213"/>
        <source>Split to volumes</source>
        <translation>Razdeli na nosilce</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="215"/>
        <source>Comment</source>
        <translation>Komentar</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="217"/>
        <source>Compress</source>
        <translation>Stisni</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Store</source>
        <translation>Shrani</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fastest</source>
        <translation>Najhitreje</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Fast</source>
        <translation>Hitro</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Normal</source>
        <translation>Navadno</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Good</source>
        <translation>Dobro</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="232"/>
        <source>Best</source>
        <translation>Najboljše</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="244"/>
        <source>Support zip, 7z type only</source>
        <translation>Podpira zgolj zip in 7z datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="247"/>
        <source>Support 7z type only</source>
        <translation>Podpira zgolj 7z datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="259"/>
        <source>Enter up to %1 characters</source>
        <translation>Vnesite do največ %1 znakov</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="280"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="281"/>
        <source>Save to</source>
        <translation>Shrani v</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="469"/>
        <source>Invalid file name</source>
        <translation>Napačno ime datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="475"/>
        <source>Please enter the path</source>
        <translation>Vnesite pot</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="480"/>
        <source>The path does not exist, please retry</source>
        <translation>Pot ne obstaja. Poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="485"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nimate pravic za shranjevanje datotek na to mesto. Spremenite lokacijo in poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="493"/>
        <source>Too many volumes, please change and retry</source>
        <translation>Preveč nosilcev. Spremenite število in poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="502"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="530"/>
        <source>%1 does not exist on the disk, please check and try again</source>
        <translation>%1 ne obstaja na disku - preverite in poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="508"/>
        <location filename="../src/source/page/compresssettingpage.cpp" line="537"/>
        <source>You do not have permission to compress %1</source>
        <translation>Nimate pravic za stiskanje %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="528"/>
        <source>The original file of %1 does not exist, please check and try again</source>
        <translation>Izvirna datoteka za %1 ne obstaja - preverite in poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="563"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="671"/>
        <source>Total size: %1</source>
        <translation>Skupna velikost: %1</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="691"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="699"/>
        <source>The password for ZIP volumes cannot be in Chinese</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Obstaja druga datoteka s tem imenom. Ali naj jo zamenjam?</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="744"/>
        <source>Replace</source>
        <translation>Zamenjaj</translation>
    </message>
    <message>
        <location filename="../src/source/page/compresssettingpage.cpp" line="784"/>
        <source>Only Chinese and English characters and some symbols are supported</source>
        <translation>Podprti so le nagleški in kitajski znaki ter nekaj posebnih znakov</translation>
    </message>
</context>
<context>
    <name>CompressView</name>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="286"/>
        <source>Open</source>
        <translation>Odpri</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="300"/>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="303"/>
        <source>Open with</source>
        <translation>Odpri z</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="309"/>
        <location filename="../src/source/tree/compressview.cpp" line="408"/>
        <source>Select default program</source>
        <translation>Določi privzeti program</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>It will permanently delete the file(s). Are you sure you want to continue?</source>
        <translation>Datoteke bodo trajno izbrisane. Aii želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <location filename="../src/source/tree/compressview.cpp" line="382"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="352"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="381"/>
        <source>Do you want to add the archive to the list or open it in new window?</source>
        <translation>Želite arhiv dodati v seznam ali ga želite odpreti v novem oknu?</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="383"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/source/tree/compressview.cpp" line="384"/>
        <source>Open in new window</source>
        <translation>Odpri v novem oknu</translation>
    </message>
</context>
<context>
    <name>ConvertDialog</name>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="352"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="353"/>
        <source>Convert</source>
        <translation>Pretvori</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="320"/>
        <source>Changes to archives in this file type are not supported. Please convert the archive format to save the changes.</source>
        <translation>Za to vrsto datotek spreminjanje arhivov ni podprto. Pretvorite vrsto arhiva, da bi shranili spremembe.</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="328"/>
        <source>Convert the format to:</source>
        <translation>Pretvori format v:</translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <location filename="../src/source/tree/datamodel.cpp" line="70"/>
        <source>item(s)</source>
        <translation>Predmet(ov)</translation>
    </message>
</context>
<context>
    <name>FailurePage</name>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="76"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Razširanje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="84"/>
        <source>Damaged file, unable to extract</source>
        <translation>Poškodovana datoteka, razširjanje ni možno</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="89"/>
        <source>Retry</source>
        <translation>Ponovi</translation>
    </message>
    <message>
        <location filename="../src/source/page/failurepage.cpp" line="92"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="56"/>
        <source>Drag file or folder here</source>
        <translation>Sem povlecite datoteko ali imenik</translation>
    </message>
    <message>
        <location filename="../src/source/page/homepage.cpp" line="58"/>
        <source>Select File</source>
        <translation>Izberite datoteko</translation>
    </message>
</context>
<context>
    <name>LoadCorruptQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="522"/>
        <source>The archive is damaged</source>
        <translation>Arhiv je poškodovan</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="525"/>
        <source>Open as read-only</source>
        <translation>Odpri samo za branje</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="526"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
</context>
<context>
    <name>LoadingPage</name>
    <message>
        <location filename="../src/source/page/loadingpage.cpp" line="65"/>
        <source>Loading, please wait...</source>
        <translation>Nalagam, počakajte...</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="54"/>
        <location filename="../src/main.cpp" line="55"/>
        <source>Archive Manager</source>
        <translation>Upravitelj arhivov</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="56"/>
        <source>Archive Manager is a fast and lightweight application for creating and extracting archives.</source>
        <translation>Upravitelj arhivov je hiter in lahek program za ustvarjanje in razširjanje arhivov.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="171"/>
        <location filename="../src/source/mainwindow.cpp" line="190"/>
        <location filename="../src/source/mainwindow.cpp" line="442"/>
        <source>Open file</source>
        <translation>Odpri datoteko</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="172"/>
        <source>Settings</source>
        <translation>Nastavitve</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="296"/>
        <location filename="../src/source/mainwindow.cpp" line="306"/>
        <source>Create New Archive</source>
        <translation>Ustvari nov arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="347"/>
        <source>Converting</source>
        <translation>Pretvarjanje</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="354"/>
        <source>Updating comments</source>
        <translation>Posodabljanje komentarjev</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="2062"/>
        <location filename="../src/source/mainwindow.cpp" line="2084"/>
        <location filename="../src/source/mainwindow.cpp" line="2109"/>
        <source>Plugin error</source>
        <translation>Napaka vtičnika</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1317"/>
        <source>Adding successful</source>
        <translation>Dodajanje je uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2133"/>
        <source>No data in it</source>
        <translation>Ne vsebuje podatkov</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1539"/>
        <source>Adding canceled</source>
        <translation>Dodajanje je bilo prekinjeno</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1634"/>
        <source>Adding failed</source>
        <translation>Dodajanje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1704"/>
        <location filename="../src/source/mainwindow.cpp" line="2129"/>
        <source>Failed to create &quot;%1&quot;</source>
        <translation>Neuspelo ustvarjanje &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2038"/>
        <source>Compression successful</source>
        <translation>Stiskanje je uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2070"/>
        <location filename="../src/source/mainwindow.cpp" line="2137"/>
        <source>Insufficient disk space</source>
        <translation>Na disku ni dovolj prostora</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2096"/>
        <location filename="../src/source/mainwindow.cpp" line="2117"/>
        <source>Some volumes are missing</source>
        <translation>Nekateri pogoni manjkajo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2121"/>
        <source>Wrong password, please retry</source>
        <translation>Napačno geslo, poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2291"/>
        <source>Select file</source>
        <translation>Izberite datoteko</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Update</source>
        <translation>Posodobi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3086"/>
        <source>Enter up to %1 characters</source>
        <translation>Vnesite do %1 znakov</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="195"/>
        <location filename="../src/source/mainwindow.cpp" line="2962"/>
        <source>File info</source>
        <translation>Podatki o datoteki</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <source>Do you want to delete the archive?</source>
        <translation>Ali želite izbrisati arhiv?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="555"/>
        <source>%1 was changed on the disk, please import it again.</source>
        <translation>%1 na disku je bil spremenjen. Uvozite ga znova.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <location filename="../src/source/mainwindow.cpp" line="1426"/>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <location filename="../src/source/mainwindow.cpp" line="2808"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="73"/>
        <source>Archive Manager</source>
        <translation>Upravitelj arhivov</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="525"/>
        <location filename="../src/source/mainwindow.cpp" line="558"/>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="674"/>
        <location filename="../src/source/mainwindow.cpp" line="1349"/>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <location filename="../src/source/mainwindow.cpp" line="2719"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="128"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nimate pravic za shranjevanje na to mesto. Spremenite lokacijo in poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="319"/>
        <source>Adding files to %1</source>
        <translation>Dodajanje datotek v %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="326"/>
        <source>Compressing</source>
        <translation>Stiskanje</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="333"/>
        <source>Extracting</source>
        <translation>Razširjanje</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="340"/>
        <source>Deleting</source>
        <translation>Brisanje</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="445"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="515"/>
        <location filename="../src/source/mainwindow.cpp" line="2786"/>
        <source>Loading, please wait...</source>
        <translation>Nalaganje, počakajte...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="588"/>
        <source>Are you sure you want to stop the ongoing task?</source>
        <translation>Želite zaustaviti trenutno opravilo?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1323"/>
        <location filename="../src/source/mainwindow.cpp" line="1451"/>
        <source>Updating, please wait...</source>
        <translation>Posodabljanje. Počakajte...</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1699"/>
        <location filename="../src/source/mainwindow.cpp" line="2125"/>
        <source>File name too long</source>
        <translation>Predolgo ime datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2066"/>
        <source>Failed to create file</source>
        <translation>Neuspešno ustvarjanje datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2059"/>
        <source>Compression failed</source>
        <translation>Stiskanje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2459"/>
        <source>Find directory</source>
        <translation>Poišči mapo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2081"/>
        <source>Open failed</source>
        <translation>Odpiranje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1630"/>
        <location filename="../src/source/mainwindow.cpp" line="1694"/>
        <location filename="../src/source/mainwindow.cpp" line="1769"/>
        <location filename="../src/source/mainwindow.cpp" line="1824"/>
        <location filename="../src/source/mainwindow.cpp" line="2092"/>
        <source>Wrong password</source>
        <translation>Napačno geslo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="632"/>
        <location filename="../src/source/mainwindow.cpp" line="665"/>
        <source>The file format is not supported by Archive Manager</source>
        <translation>Upravitelj arhivov ne podpira formata datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="463"/>
        <location filename="../src/source/mainwindow.cpp" line="621"/>
        <source>You do not have permission to load %1</source>
        <translation>Nimate dovoljenja za nalaganje %1</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="615"/>
        <source>No such file or directory</source>
        <translation>Datoteka li mapa ne obstaja</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1365"/>
        <source>Extraction successful</source>
        <comment>提取成功</comment>
        <translation>Razširjanje je uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1560"/>
        <source>Extraction canceled</source>
        <comment>取消提取</comment>
        <translation>Razširjanje je bilo prekinjeno</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1689"/>
        <location filename="../src/source/mainwindow.cpp" line="1764"/>
        <location filename="../src/source/mainwindow.cpp" line="2088"/>
        <location filename="../src/source/mainwindow.cpp" line="2113"/>
        <source>The archive is damaged</source>
        <translation>Arhiv je poškodovan</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="1711"/>
        <source>Extraction failed</source>
        <comment>提取失败</comment>
        <translation>Razširanje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2042"/>
        <source>Extraction successful</source>
        <comment>解压成功</comment>
        <translation>Razširjanje je uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2045"/>
        <source>Conversion successful</source>
        <translation>Pretvorba je uspela</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2106"/>
        <source>Extraction failed</source>
        <comment>解压失败</comment>
        <translation>Razširanje ni uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2283"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2287"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2295"/>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2303"/>
        <source>Display shortcuts</source>
        <translation>Prikaži bljižnice</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2315"/>
        <source>Shortcuts</source>
        <translation>Bljižnice</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2381"/>
        <source>The name is the same as that of the compressed archive, please use another one</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Obstaja druga datoteka s tem imenom. Ali naj jo zamenjam?</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2389"/>
        <source>Replace</source>
        <translation>Zamenjaj</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2542"/>
        <source>You cannot add the archive to itself</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2557"/>
        <source>You cannot add files to archives in this file type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2986"/>
        <source>Basic info</source>
        <translation>Osnovni podatki</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3002"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3003"/>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3004"/>
        <source>Location</source>
        <translation>Lokacija</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3005"/>
        <source>Time created</source>
        <translation>Čas stvarjenja</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3006"/>
        <source>Time accessed</source>
        <translation>Čas dostopa</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3007"/>
        <source>Time modified</source>
        <translation>Čas spremembe</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3017"/>
        <source>Archive</source>
        <translation>Arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="3048"/>
        <source>Comment</source>
        <translation>Komentar</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="662"/>
        <source>Please check the file association type in the settings of Archive Manager</source>
        <translation>Preverite povezano vrsto datotek v nastavitvah Upravitelja arhivov</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2272"/>
        <source>The archive was changed on the disk, please import it again.</source>
        <translation>Arhiv na disku je bil spremenjen. Uvozite ga znova.</translation>
    </message>
</context>
<context>
    <name>MimeTypeDisplayManager</name>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="46"/>
        <source>Directory</source>
        <translation>Mapa</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="47"/>
        <source>Application</source>
        <translation>Program</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="48"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="49"/>
        <source>Audio</source>
        <translation>Zvok</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="50"/>
        <source>Image</source>
        <translation>Posnetek</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="51"/>
        <source>Archive</source>
        <translation>Arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="53"/>
        <source>Executable</source>
        <translation>Zagonska</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="52"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="54"/>
        <source>Backup file</source>
        <translation>Varnostna datoteka</translation>
    </message>
    <message>
        <location filename="../src/source/common/mimetypedisplaymanager.cpp" line="55"/>
        <source>Unknown</source>
        <translation>neznan</translation>
    </message>
</context>
<context>
    <name>OpenWithDialog</name>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="280"/>
        <source>Open with</source>
        <translation>Odpri z</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="299"/>
        <source>Add other programs</source>
        <translation>Dodaj druge programe</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="300"/>
        <source>Set as default</source>
        <translation>Določi za privzeto</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="302"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="303"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="307"/>
        <source>Recommended Applications</source>
        <translation>Priporočeni programi</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/openwithdialog/openwithdialog.cpp" line="309"/>
        <source>Other Applications</source>
        <translation>Drugi programi</translation>
    </message>
</context>
<context>
    <name>PasswordNeededQuery</name>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="394"/>
        <source>Encrypted file, please enter the password</source>
        <translation>Šifirirana datoteka, vnesite geslo</translation>
    </message>
</context>
<context>
    <name>PreviousLabel</name>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="52"/>
        <source>Current path:</source>
        <translation>Trenutna pot:</translation>
    </message>
    <message>
        <location filename="../src/source/tree/treeheaderview.cpp" line="60"/>
        <source>Back to: %1</source>
        <translation>Nazaj na: %1</translation>
    </message>
</context>
<context>
    <name>ProgressDialog</name>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="52"/>
        <source>%1 task(s) in progress</source>
        <translation>Izvaja se %1 opravil</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="59"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="102"/>
        <source>Task</source>
        <translation>Opravilo</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="65"/>
        <location filename="../src/source/dialog/progressdialog.cpp" line="113"/>
        <source>Extracting</source>
        <translation>Razširjam</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="192"/>
        <source>Are you sure you want to stop the extraction?</source>
        <translation>Ali želite zaustaviti razširjanje?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/progressdialog.cpp" line="194"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="306"/>
        <location filename="../src/source/page/progresspage.cpp" line="309"/>
        <location filename="../src/source/page/progresspage.cpp" line="312"/>
        <source>Speed</source>
        <comment>compress</comment>
        <translation>Hitrost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="52"/>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="144"/>
        <source>Calculating...</source>
        <translation>Preračunavanje...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="54"/>
        <location filename="../src/source/page/progresspage.cpp" line="316"/>
        <location filename="../src/source/page/progresspage.cpp" line="318"/>
        <source>Speed</source>
        <comment>delete</comment>
        <translation>Hitrost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="56"/>
        <location filename="../src/source/page/progresspage.cpp" line="330"/>
        <location filename="../src/source/page/progresspage.cpp" line="332"/>
        <location filename="../src/source/page/progresspage.cpp" line="334"/>
        <source>Speed</source>
        <comment>convert</comment>
        <translation>Hitrost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="60"/>
        <location filename="../src/source/page/progresspage.cpp" line="322"/>
        <location filename="../src/source/page/progresspage.cpp" line="324"/>
        <location filename="../src/source/page/progresspage.cpp" line="326"/>
        <source>Speed</source>
        <comment>uncompress</comment>
        <translation>Hitrost</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="63"/>
        <location filename="../src/source/page/progresspage.cpp" line="302"/>
        <source>Time left</source>
        <translation>Preostali čas</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="117"/>
        <source>Compressing</source>
        <translation>Stiskam</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="119"/>
        <source>Deleting</source>
        <translation>Brisanje</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="121"/>
        <source>Converting</source>
        <translation>Pretvarjanje</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="123"/>
        <location filename="../src/source/page/progresspage.cpp" line="142"/>
        <source>Updating the comment...</source>
        <translation>Posodabljanje komentarja...</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="125"/>
        <source>Extracting</source>
        <translation>Razširjanje</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="172"/>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="368"/>
        <source>Are you sure you want to stop the decompression?</source>
        <translation>Želite res zaustaviti razširjanje?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="370"/>
        <source>Are you sure you want to stop the deletion?</source>
        <translation>Želite res zaustaviti brisanje?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="136"/>
        <location filename="../src/source/page/progresspage.cpp" line="173"/>
        <location filename="../src/source/page/progresspage.cpp" line="350"/>
        <source>Pause</source>
        <translation>Premor</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="346"/>
        <source>Continue</source>
        <translation>Nadaljuj</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="366"/>
        <location filename="../src/source/page/progresspage.cpp" line="372"/>
        <source>Are you sure you want to stop the compression?</source>
        <translation>Ali želite zaustaviti stiskanje?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="374"/>
        <source>Are you sure you want to stop the conversion?</source>
        <translation>Želite zaustaviti pretvorbo?</translation>
    </message>
    <message>
        <location filename="../src/source/page/progresspage.cpp" line="379"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Time modified</source>
        <translation>Čas spremembe</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <location filename="../src/source/tree/datamodel.h" line="71"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../src/source/mainwindow.cpp" line="2805"/>
        <source>%1 changed. Do you want to save changes to the archive?</source>
        <translation>Sprememba v %1. Želite shraniti spremembe v arhiv?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="405"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="500"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="26"/>
        <source>General</source>
        <translation>Splošno</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="27"/>
        <source>Extraction</source>
        <translation>Razširjanje</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="28"/>
        <source>Auto create a folder for multiple extracted files</source>
        <translation>Samodejno ustvari mapo za več razširjenih datotek</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="29"/>
        <source>Show extracted files when completed</source>
        <translation>Ko končaš, prikaži razširjene datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="30"/>
        <source>File Management</source>
        <translation>Upravljanje datotek</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="31"/>
        <source>Delete files after compression</source>
        <translation>Po stiskanju izbriši datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="32"/>
        <source>Files Associated</source>
        <translation>Povezane datoteke</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settings_translation.cpp" line="33"/>
        <source>File Type</source>
        <translation>Vrsta datoteke</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="406"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="501"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="221"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="206"/>
        <source>Another file with the same name already exists, replace it?</source>
        <translation>Obstaja druga datoteka s tem imenom. Ali naj jo zamenjam?</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="244"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="202"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="208"/>
        <source>Skip</source>
        <translation>Preskoči</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="200"/>
        <source>Another folder with the same name already exists, replace it?</source>
        <translation>Mapa s tem imenom že obstaja. Jo zamenjam?</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/popupdialog.cpp" line="203"/>
        <source>Merge</source>
        <translation>Združi</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="245"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="209"/>
        <source>Replace</source>
        <translation>Zamenjaj</translation>
    </message>
    <message>
        <location filename="../3rdparty/interface/queries.cpp" line="226"/>
        <location filename="../src/source/dialog/popupdialog.cpp" line="212"/>
        <source>Apply to all</source>
        <translation>Uveljavi na vseh</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="403"/>
        <source>Open file</source>
        <translation>Odpri datoteko</translation>
    </message>
    <message>
        <location filename="../tests/UnitTest/src/source/ut_mainwindow.cpp" line="409"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="124"/>
        <source>Select All</source>
        <translation>Izberi vse</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="195"/>
        <source>Current directory</source>
        <translation>Trenutni imenik</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="125"/>
        <source>Clear All</source>
        <translation>Počisti vse</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="126"/>
        <source>Recommended</source>
        <translation>Priporočeno</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="160"/>
        <source>Extract archives to</source>
        <translation>Razširi arhive v</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="205"/>
        <source>Other directory</source>
        <translation>Drug imenik</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="166"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="200"/>
        <source>Desktop</source>
        <translation>Namizje</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="272"/>
        <source>Delete archives after extraction</source>
        <translation>Po razširitvi izbriši arhiv</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="299"/>
        <source>Never</source>
        <translation>Nikoli</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="302"/>
        <source>Ask for confirmation</source>
        <translation>Vprašaj za potrditev</translation>
    </message>
    <message>
        <location filename="../src/source/dialog/settingdialog.cpp" line="278"/>
        <location filename="../src/source/dialog/settingdialog.cpp" line="305"/>
        <source>Always</source>
        <translation>Vedno</translation>
    </message>
</context>
<context>
    <name>SuccessPage</name>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="74"/>
        <source>Compression successful</source>
        <translation>Stiskanje je uspelo</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="79"/>
        <source>View</source>
        <translation>Prikaz</translation>
    </message>
    <message>
        <location filename="../src/source/page/successpage.cpp" line="82"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
</context>
<context>
    <name>UnCompressPage</name>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="120"/>
        <source>Extract</source>
        <translation>Razširi</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="74"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="85"/>
        <location filename="../src/source/page/uncompresspage.cpp" line="119"/>
        <source>Extract to:</source>
        <translation>Razširi v:</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="194"/>
        <source>The default extraction path does not exist, please retry</source>
        <translation>Privzeta pot za razširitev ne obstaja. Poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="196"/>
        <source>You do not have permission to save files here, please change and retry</source>
        <translation>Nimate pravic za shranjevanje na to mesto. Spremenite lokacijo in poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="214"/>
        <source>Find directory</source>
        <translation>Iskanje mape</translation>
    </message>
    <message>
        <location filename="../src/source/page/uncompresspage.cpp" line="200"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
</context>
<context>
    <name>UnCompressView</name>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>You cannot add the archive to itself</source>
        <translation>Arhiva ne morete dodajati samega vase</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="389"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="615"/>
        <source>Extract</source>
        <comment>提取</comment>
        <translation>Razširi</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="617"/>
        <source>Extract to current directory</source>
        <translation>Razširi v trenutni imenik</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="619"/>
        <source>Open</source>
        <translation>Odpri</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="622"/>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="629"/>
        <source>Open with</source>
        <translation>Odpri z</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="633"/>
        <location filename="../src/source/tree/uncompressview.cpp" line="734"/>
        <source>Select default program</source>
        <translation>Določi privzeti program</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Cancel</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Confirm</source>
        <translation>Potrdi</translation>
    </message>
    <message>
        <location filename="../src/source/tree/uncompressview.cpp" line="684"/>
        <source>Do you want to delete the selected file(s)?</source>
        <translation>Želite izbrisati izbrane datoteke?</translation>
    </message>
</context>
</TS>